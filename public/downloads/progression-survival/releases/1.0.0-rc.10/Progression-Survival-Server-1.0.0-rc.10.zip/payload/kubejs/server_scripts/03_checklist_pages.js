// Checklist presentation is appended to 00_progression.js so it can read the existing personal state directly without a writable global.
