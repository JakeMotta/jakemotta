param([Parameter(Position=0)][string]$Command='list')
$ErrorActionPreference='Stop'
$taskProperties=@{}
Get-Content -LiteralPath (Join-Path $PSScriptRoot 'server.properties') | ForEach-Object {
 if($_ -match '^([^#=]+)=(.*)$'){$taskProperties[$matches[1]]=$matches[2]}
}
function Read-Exact([IO.Stream]$Stream,[int]$Length){
 $taskBuffer=New-Object byte[] $Length
 $taskOffset=0
 while($taskOffset -lt $Length){
  $taskRead=$Stream.Read($taskBuffer,$taskOffset,$Length-$taskOffset)
  if($taskRead -eq 0){throw 'The server closed the administration connection.'}
  $taskOffset+=$taskRead
 }
 return ,$taskBuffer
}
function Send-Packet([IO.Stream]$Stream,[int]$Id,[int]$Type,[string]$Body){
 $taskBody=[Text.Encoding]::UTF8.GetBytes($Body)
 $taskData=[BitConverter]::GetBytes([int]($taskBody.Length+10))+[BitConverter]::GetBytes($Id)+[BitConverter]::GetBytes($Type)+$taskBody+[byte[]]@(0,0)
 $Stream.Write($taskData,0,$taskData.Length)
}
function Read-Packet([IO.Stream]$Stream){
 $taskLength=[BitConverter]::ToInt32((Read-Exact $Stream 4),0)
 if($taskLength -lt 10 -or $taskLength -gt 4194304){throw 'Invalid administration response.'}
 $taskPayload=Read-Exact $Stream $taskLength
 return @{Id=[BitConverter]::ToInt32($taskPayload,0);Type=[BitConverter]::ToInt32($taskPayload,4);Text=[Text.Encoding]::UTF8.GetString($taskPayload,8,$taskLength-10)}
}
$taskConnection=[Net.Sockets.TcpClient]::new()
try{
 $taskPending=$taskConnection.ConnectAsync('127.0.0.1',[int]$taskProperties['rcon.port'])
 if(-not $taskPending.Wait(5000)){throw 'The local progression server is not responding.'}
 $taskStream=$taskConnection.GetStream();$taskStream.ReadTimeout=15000;$taskStream.WriteTimeout=5000
 Send-Packet $taskStream 1 3 $taskProperties['rcon.password']
 $taskReply=Read-Packet $taskStream
 if($taskReply.Type -eq 0){$taskReply=Read-Packet $taskStream}
 if($taskReply.Id -ne 1 -or $taskReply.Type -ne 2){throw 'Local administration authentication failed.'}
 Send-Packet $taskStream 2 2 $Command
 $taskReply=Read-Packet $taskStream
 if($taskReply.Id -ne 2){throw 'Unexpected command response.'}
 Write-Output $taskReply.Text
}finally{$taskConnection.Dispose()}
