// Jake's personal progression adapter for Minecraft 1.21.1 / NeoForge.
var JP_RULES=JSON.parse(JsonIO.readString('kubejs/config/progression_rules.json'));
var JP=global.JakeEngineFactory(JP_RULES);
var JP_DB=null,JP_DIRTY=false,JP_TICK=0,JP_SERVER=null,JP_ERROR_ONCE={},JP_LAST_KILL=null;
var JP_Player=Java.loadClass('net.minecraft.server.level.ServerPlayer');
var JP_Enemy=Java.loadClass('net.minecraft.world.entity.monster.Enemy');
var JP_QuestFile=Java.loadClass('dev.ftb.mods.ftbquests.quest.ServerQuestFile');
var JP_Long=Java.loadClass('java.lang.Long');
var JP_Stats=Java.loadClass('net.minecraft.stats.Stats');
var JP_Registries=Java.loadClass('net.minecraft.core.registries.Registries');
var JP_RL=Java.loadClass('net.minecraft.resources.ResourceLocation');
var JP_Tag=Java.loadClass('net.minecraft.tags.TagKey');
var JP_LevelResource=Java.loadClass('net.minecraft.world.level.storage.LevelResource');
var JP_RecipeType=Java.loadClass('net.minecraft.world.item.crafting.RecipeType');
function jpId(p){return String(p.uuid);}
function jpError(key,e){if(!JP_ERROR_ONCE[key]){JP_ERROR_ONCE[key]=true;console.error('[JakeProgression] '+key+': '+e);}}
function jpStatePath(){return String(JP_SERVER.getWorldPath(JP_LevelResource.ROOT))+'/jake-progress.json';}
function jpLoad(server){
  JP_SERVER=server;
  if(JP_DB)return;
  var path=jpStatePath(),raw=JsonIO.readString(path);
  JP_DB=raw&&raw!=='null'?JSON.parse(raw):JP.fresh();
  if(JP_DB.schema!==1||!JP_DB.players||!JP_DB.crops)throw new Error('Unsupported or corrupt personal progression state; refusing to reset it.');
  if(JP_RULES.mining.tierScoped)Object.keys(JP_DB.players).forEach(function(id){if(JP_DB.players[id].tierMiningVersion!==1){JP.evaluate(JP_DB.players[id]);JP_DIRTY=true;}});
  Object.keys(JP_DB.players).forEach(function(id){jpPrepareTaskRewards(JP_DB.players[id]);});
  console.info('[JakeProgression] Loaded personal state for '+Object.keys(JP_DB.players).length+' players.');
}
function jpSave(){
  if(!JP_DB||!JP_DIRTY)return;
  var path=jpStatePath();
  var previous=JsonIO.readString(path);
  if(previous&&previous!=='null')JsonIO.write(path+'.bak',JSON.parse(previous));
  JsonIO.write(path+'.pending',JP_DB);
  JsonIO.write(path,JP_DB);
  JP_DIRTY=false;
}
function jpPlayer(p){jpLoad(p.server);var s=JP.person(JP_DB,jpId(p));s.name=String(p.getGameProfile().getName());return s;}
function jpStage(p,stage){if(!AStages.playerHasStage(p,stage))AStages.addStageToPlayer(p,stage,false,true,false);}
function jpApply(p,event){
  if(!(p instanceof JP_Player)||p.isSpectator()||p.isCreative())return;
  jpLoad(p.server);var previous={},before=jpPlayer(p);Object.keys(before.unlocks).forEach(function(key){if(before.unlocks[key])previous[key]=true;});
  jpPrepareJournalNotices(before);
  jpPrepareTaskRewards(before);
  var s=JP.act(JP_DB,jpId(p),event);s.name=String(p.getGameProfile().getName());JP_DIRTY=true;
  jpTierUnlockNotices(p,s,previous);
  Object.keys(s.unlocks).forEach(function(k){jpStage(p,'jake_'+k);});
  jpOptionalRewards(p,s);
  jpGrantTaskRewards(p,s);
}
function jpArmor(p){return [String(p.headArmorItem.id),String(p.chestArmorItem.id),String(p.legsArmorItem.id),String(p.feetArmorItem.id)];}
function jpPos(level,pos){return String(level.dimension)+'|'+pos.getX()+','+pos.getY()+','+pos.getZ();}
function jpItem(stack){return String(stack.id);}
function jpCrop(id){return {'minecraft:wheat':'wheat','minecraft:carrots':'carrots','minecraft:potatoes':'potatoes'}[id]||null;}
function jpSync(p){
  var state=jpPlayer(p),file=JP_QuestFile.INSTANCE;
  if(!file)return;
  var data=file.getTeamData(p);
  if(!data.isPresent())return;
  var team=data.get();
  JP_RULES.quests.forEach(function(q){q.tasks.forEach(function(t){
    var task=file.getTask(JP_Long.parseLong(t.id,16));
    if(!task)throw new Error('Missing quest task '+t.id);
    task.setMaxProgress(t.target);
    task.setEnableButton(false);
    var n=JP.active(state,q.key)?Math.min(t.target,JP.progress(state,t.key)):0;
    if(team.getProgress(task)!==n)team.setProgress(task,n);
  });});
}
// Item restrictions allow storage, but never equipping, attacking, or mining.
Object.keys(JP_RULES.items).forEach(function(item){
  var m=JP_RULES.items[item],stage='jake_'+m.track+'_'+m.tier;
  AStages.addRestrictionForItem('jake:item/'+item.replace(':','/'),stage,item)
    .allowPickup().allowInventoryStorage().allowContainerStorage().showInRecipeViewer().globalShowName();
});
// Operator-only reversible fixture in empty air above spawn. Restores its blocks.

Object.keys(JP_RULES.armor).forEach(function(t){AStages.customizeStage('jake_armor_'+t).playerOnly();});
Object.keys(JP_RULES.tools).forEach(function(t){AStages.customizeStage('jake_tools_'+t).playerOnly();});
JP_RULES.recipes.forEach(function(r){
  var m=JP_RULES.items[r.item];
  // Armor may be crafted before its wear stage; tool recipe gates are unchanged.
  if(m.track==='armor')return;
  AStages.addRestrictionForRecipe('jake:recipe/'+r.id.replace(':','/'),'jake_'+m.track+'_'+m.tier,r.type.indexOf('smithing')===0?JP_RecipeType.SMITHING:JP_RecipeType.CRAFTING,r.id);
});
ServerEvents.recipes(function(e){
  var patterns={helmet:['CCC','C C'],chestplate:['C C','CCC','CCC'],leggings:['CCC','C C','C C'],boots:['C C','C C'],pickaxe:['CCC',' S ',' S '],axe:['CC ','CS ',' S '],shovel:[' C ',' S ',' S '],hoe:['CC ',' S ',' S '],sword:[' C ',' C ',' S ']};
  Object.keys(patterns).forEach(function(slot){
    var item='copperequipment:copper_'+slot;
    e.remove({output:item});
    var keys={C:'minecraft:copper_ingot'};if(patterns[slot].join('').indexOf('S')>=0)keys.S='minecraft:stick';
    e.shaped(item,patterns[slot],keys).id('copperequipment:copper_'+slot);
    if(['helmet','chestplate','leggings','boots'].indexOf(slot)>=0)e.shaped('minecraft:chainmail_'+slot,patterns[slot],{C:'minecraft:iron_nugget'}).id('kubejs:chainmail_'+slot);
  });
});
ServerEvents.loaded(function(e){jpLoad(e.server);console.info('[JakeProgression] '+JP_RULES.quests.length+' quests and '+JP_RULES.recipes.length+' gated recipes configured.');});
ServerEvents.unloaded(function(){jpSave();});
ServerEvents.command('reload',function(){jpSave();});
ServerEvents.tick(function(e){if(!JP_DB)jpLoad(e.server);if(++JP_TICK%100===0){try{jpSave();}catch(err){jpError('save',err);}}});
PlayerEvents.loggedIn(function(e){
  jpLoad(e.server);var s=jpPlayer(e.player);JP.evaluate(s);Object.keys(s.unlocks).forEach(function(k){jpStage(e.player,'jake_'+k);});
  e.player.tell('Welcome! Open the quest book or use /progress. Unlocks are personal. Complete the Copper armor challenge to advance toward Iron.');
});
PlayerEvents.loggedOut(function(){jpSave();});
ItemEvents.crafted(function(e){
  if(!(e.player instanceof JP_Player))return;
  var output=jpItem(e.item),info=JP.itemInfo(output),waxing=false;
  if(info&&output.indexOf(':waxed_')>=0){
    for(var i=0;i<e.inventory.containerSize;i++){
      var ingredient=JP.itemInfo(jpItem(e.inventory.getItem(i)));
      if(ingredient&&ingredient.canonical===info.canonical)waxing=true;
    }
  }
  jpApply(e.player,{type:'craft',item:output,count:Number(e.item.count),waxing:waxing});
});
Object.keys(JP_RULES.smithing_proofs).forEach(function(proof){
  PlayerEvents.advancement(proof,function(e){jpApply(e.player,{type:'craft',item:JP_RULES.smithing_proofs[proof],count:1});});
});
BlockEvents.placed(function(e){
  if(!(e.player instanceof JP_Player))return;
  var p=e.player,level=p.level,pos=e.block.pos.immutable(),id=String(e.block.id),key=jpPos(level,pos),crop=jpCrop(id);
  e.server.scheduleInTicks(1,function(){
    if(String(level.getBlockState(pos).block.id)!==id)return;
    if(crop)jpApply(p,{type:'plant',crop:crop,pos:key});else if(JP_DB&&JP_DB.crops[key]){delete JP_DB.crops[key];JP_DIRTY=true;}
  });
});
BlockEvents.broken(function(e){
  if(!(e.player instanceof JP_Player))return;
  var p=e.player,level=p.level,pos=e.block.pos.immutable(),id=String(e.block.id),held=p.mainHandItem.copy(),key=jpPos(level,pos);
  var dungeonProof=id==='minecraft:spawner'?jpDungeonAt(level,pos):null;
  var crop=jpCrop(id),mature=crop&&String(e.block.properties.get('age'))==='7',log=e.block.hasTag('minecraft:logs'),suitable=held.isCorrectToolForDrops(e.block.blockState);
  var soil=['minecraft:farmland','minecraft:dirt','minecraft:grass_block','minecraft:coarse_dirt','minecraft:rooted_dirt','minecraft:sand','minecraft:red_sand','minecraft:gravel','minecraft:clay','minecraft:snow_block','minecraft:soul_sand','minecraft:soul_soil'].indexOf(id)>=0;
  var beforeCrop=JP_DB?JP_DB.crops[key]:null;
  e.server.scheduleInTicks(1,function(){
    var after=level.getBlockState(pos);
    if(String(after.block.id)===id&&(!crop||String(after.getValue(Java.loadClass('net.minecraft.world.level.block.state.properties.BlockStateProperties').AGE_7))==='7'))return;
    if(dungeonProof)jpDungeonCredit(p,level,pos,dungeonProof);
    // Preserve a legitimate intervening replant, but do not credit cancelled events.
    var replacement=JP_DB?JP_DB.crops[key]:null;
    if(beforeCrop)JP_DB.crops[key]=beforeCrop;else delete JP_DB.crops[key];
    jpApply(p,{type:'break',block:id,held:jpItem(held),pos:key,crop:crop,mature:!!mature,log:!!log,soil:soil,suitable:!!suitable});
    if(replacement&&replacement!==beforeCrop)JP_DB.crops[key]=replacement;
  });
});
BlockEvents.rightClicked(function(e){
  if(!(e.player instanceof JP_Player)||String(e.hand)!=='MAIN_HAND')return;
  var m=JP.itemInfo(jpItem(e.item));if(!m||m.slot!=='hoe')return;
  var p=e.player,level=p.level,pos=e.block.pos.immutable(),before=String(e.block.id),held=jpItem(e.item);
  if(['minecraft:dirt','minecraft:grass_block','minecraft:dirt_path'].indexOf(before)<0)return;
  e.server.scheduleInTicks(1,function(){if(String(level.getBlockState(pos).block.id)==='minecraft:farmland')jpApply(p,{type:'till',held:held});});
});
EntityEvents.death(function(e){
  var attacker=e.source.actual;
  JP_LAST_KILL={mob:String(e.entity.type),attacker:attacker?String(attacker.type):null,isPlayer:attacker instanceof JP_Player,armor:attacker instanceof JP_Player?jpArmor(attacker):[]};
  if(!(attacker instanceof JP_Player)||e.entity instanceof JP_Player)return;
  if(e.entity.getTags().contains('jake-difficulty-test'))return;
  var victim=e.entity,id=String(victim.type),armor=jpArmor(attacker),held=jpItem(attacker.mainHandItem);
  var direct=e.source.direct,ranged=null;
  if(direct&&String(direct.type)==='minecraft:arrow')ranged=direct.shotFromCrossbow()?'crossbow':'bow';
  e.server.scheduleInTicks(1,function(){if(victim.isAlive())return;jpApply(attacker,{type:'kill',personal:true,mob:id,armor:armor,held:held,ranged:ranged,hostile:victim instanceof JP_Enemy});});
});
function jpStructure(p,id,tag){
  var level=p.level,key=JP_RL.parse(id);
  var structure=tag?JP_Tag.create(JP_Registries.STRUCTURE,key):level.registryAccess().registryOrThrow(JP_Registries.STRUCTURE).get(key);
  if(structure===null)return false;
  var method=tag?'getStructureWithPieceAt(net.minecraft.core.BlockPos,net.minecraft.tags.TagKey)':'getStructureWithPieceAt(net.minecraft.core.BlockPos,net.minecraft.world.level.levelgen.structure.Structure)';
  return level.structureManager()[method](p.blockPosition(),structure).isValid();
}
function jpPoll(p){
  if(!(p instanceof JP_Player)||p.tickCount%40!==0)return;
  try{
    var state=jpPlayer(p),dimension=String(p.level.dimension);
    jpUpdateMultiChecklists(p,state);
    var biome=String(p.level.getBiome(p.blockPosition()).unwrapKey().get().location());
    var village=false,fortress=false;
    if(JP.active(state,'explore')&&dimension==='minecraft:overworld'&&!state.done.explore)village=jpStructure(p,'minecraft:village',true);
    if(JP.active(state,'nether')&&dimension==='minecraft:the_nether'&&!state.done.nether)fortress=jpStructure(p,'minecraft:fortress',false);
    var advancements=[];
    JP_RULES.advancements.forEach(function(id){var h=p.server.getAdvancements().get(JP_RL.parse(id));if(h&&p.getAdvancements().getOrStartProgress(h).isDone())advancements.push(id);});
    jpApply(p,{type:'poll',dimension:dimension,biome:biome,village:village,fortress:fortress,xp:Number(p.experienceLevel),coal:Number(p.inventory.count('minecraft:coal')),advancements:advancements,dietFoods:jpDietFoods(p),structures:jpOptionalVisits(p,state)});
    // Hidden recipe_crafted advancements prove a personal smithing operation,
    // including shift-click output. Inventory possession is never used as proof.
    Object.keys(JP_RULES.smithing_proofs).forEach(function(proof){
      var item=JP_RULES.smithing_proofs[proof],m=JP.itemInfo(item);
      if((m.track!=='armor'&&!JP.allowed(state,m.track,m.tier))||state.crafted[item])return;
      var holder=p.server.getAdvancements().get(JP_RL.parse(proof));
      if(holder&&p.getAdvancements().getOrStartProgress(holder).isDone())jpApply(p,{type:'craft',item:item,count:1});
    });
    jpSync(p);
  }catch(err){jpError('player tick',err);}
}
PlayerEvents.tick(function(e){jpPoll(e.player);});
ServerEvents.basicPublicCommand('progress',function(e){
  var p=e.player;if(!p){e.respond(Text.of('Player-only command.'));return;}
  var s=jpPlayer(p),lines=['Your personal progression:'];
  JP_RULES.quests.forEach(function(q){
    if(s.done[q.key])lines.push('[DONE] '+q.title);
    else if(JP.active(s,q.key))lines.push(q.title+': '+q.tasks.map(function(t){return t.title+' '+Math.min(t.target,JP.progress(s,t.key))+'/'+t.target;}).join('; '));
  });
  lines.forEach(function(line){p.tell(line);});
});

// Read-only projection for the checklist presentation; personal rules remain authoritative.
function jpChecklistView(player){
  var state=jpPlayer(player),counts={};
  JP_RULES.quests.forEach(function(q){q.tasks.forEach(function(t){counts[t.key]=JP.progress(state,t.key);});});
  Object.keys(JP_RULES.dungeons||{}).forEach(function(type){counts['dungeon:'+type]=JP.progress(state,'dungeon:'+type);});
  Object.keys(JP_RULES.multiChecklists||{}).forEach(function(key){counts[key]=JP.progress(state,key);JP_RULES.multiChecklists[key].entries.forEach(function(entry){counts[entry.key]=JP.progress(state,entry.key);});});
  JP_RULES.fishing.items.forEach(function(item){counts['fish:'+item]=JP.progress(state,'fish:'+item);});
  ChecklistPages.forEach(function(card){card.tasks.forEach(function(task){(task.details||[]).forEach(function(entry){counts[entry.key]=JP.progress(state,entry.key);});});});
  (JP_RULES.dietFoods||[]).forEach(function(food){counts['diet:'+food]=JP.progress(state,'diet:'+food);});
  Object.keys(JP_RULES.mining.ores).forEach(function(block){var key='mined:'+JP_RULES.mining.ores[block];counts[key]=JP.progress(state,key);});
  return {done:state.done,unlocks:state.unlocks,counts:counts};
};

console.info('[JakeProgression] Server event adapters registered.');
// Operator-only, non-player audit. Does not grant real players stages or change
// world blocks. Synthetic native events test adapter wiring, not a real login.




// CHECKLIST PRESENTATION MODULE (same scope as personal rules adapter)
// Display-only checklist rows; never grant stages or mutate personal counters.
var ChecklistBook=Java.loadClass('dev.ftb.mods.ftbquests.quest.ServerQuestFile');
var ChecklistLong=Java.loadClass('java.lang.Long');
var ChecklistPages=JSON.parse(JsonIO.readString('kubejs/config/checklist_pages.json')).cards;
var ChecklistFailed=false;
function checklistState(player){return jpChecklistView(player);}
function checklistSync(player){
  if(!ChecklistBook.INSTANCE)return;
  var data=ChecklistBook.INSTANCE.getTeamData(player);if(!data.isPresent())return;
  var team=data.get(),state=checklistState(player);
  ChecklistPages.forEach(function(card){card.tasks.forEach(function(row){
    var task=ChecklistBook.INSTANCE.getTask(ChecklistLong.parseLong(row.id,16));if(!task)return;
    task.setMaxProgress(row.target);task.setEnableButton(false);
    var value=Math.min(row.target,Number(state.counts[row.key]||0));
    if(Number(team.getProgress(task))!==value)team.setProgress(task,value);
  });});
}
PlayerEvents.tick(function(event){
  if(event.player.tickCount%20!==0)return;
  try{checklistSync(event.player);}catch(error){if(!ChecklistFailed){ChecklistFailed=true;console.error('[ChecklistPages] '+error);}}
});
function checklistScore(card,state){return card.tasks.reduce(function(sum,t){return sum+Math.min(1,Number(state.counts[t.key]||0)/t.target);},0)/card.tasks.length;}
function checklistNext(track,state){
  var stages=track==='armor'?['copper','iron','gold','diamond','netherite']:['stone','copper','iron','gold','diamond','netherite'];
  var goal='master';for(var i=0;i<stages.length;i++){if(!state.unlocks[track+'_'+stages[i]]){goal=stages[i];break;}}
  var choices=ChecklistPages.filter(function(c){return c.track===track&&c.goal===goal;});
  choices.sort(function(a,b){return checklistScore(b,state)-checklistScore(a,state);});return choices[0];
}
ServerEvents.basicPublicCommand('next',function(event){
  var player=event.player;if(!player){event.respond(Text.of('Player-only command.'));return;}
  var state=checklistState(player);
  ['armor','tools'].forEach(function(track){
    var card=checklistNext(track,state),remaining=card.tasks.filter(function(row){return Number(state.counts[row.key]||0)<row.target;});
    player.tell('--- '+card.title+' ---');
    if(!remaining.length)player.tell('[DONE] Every checklist item is complete.');
    remaining.forEach(function(row){player.tell('[ ] '+row.title+': '+Math.min(row.target,Number(state.counts[row.key]||0))+'/'+row.target);});
  });
  player.tell('Quest book: START HERE: Armor checklists / NEXT: Tool checklists.');
});

console.info('[ChecklistPages] '+ChecklistPages.length+' display-only checklist cards registered.');
// Append once to 00_progression.js, which owns jpChecklistView and ChecklistPages.
// This adapter publishes read-only display data; it never grants stages.
// Append once to 00_progression.js, which owns jpChecklistView and ChecklistPages.
// This adapter publishes read-only display data; it never grants stages.
// Append once to 00_progression.js, which owns jpChecklistView and ChecklistPages.
// This adapter publishes read-only display data; it never grants stages.
// Append once to 00_progression.js, which owns jpChecklistView and ChecklistPages.
// This adapter publishes read-only display data; it never grants stages.
// JOURNAL BRIDGE BEGIN
var JournalBridgeClass=null;
try { JournalBridgeClass=Java.loadClass('dev.jake.progression.ProgressionBridge'); }
catch(ignored) { console.info('[ProgressionJournal] Companion not installed; native quest book remains available.'); }
var JournalBridgeFailed=false;
var JournalQuestRules=JP_RULES.quests.filter(function(q){return q.key.indexOf('armor_')!==0&&q.key.indexOf('tools_')!==0&&q.key!=='mid_armor'&&!q.optionalRetired&&(JP_RULES.journalRequiredQuests||[]).indexOf(q.key)<0;});
var JournalQuestCards=JournalQuestRules.map(function(q){
  return {key:'quest_'+q.key,title:q.title,track:'quests',goal:q.key,description_text:q.description,category:q.category||'Other',rewardXp:q.rewardXp||0,
    prerequisites:(q.dependencies||[]).map(function(key){var found=JP_RULES.quests.filter(function(other){return other.key===key;});return found.length?found[0].title:key;}),
    tasks:q.tasks.map(function(t){return {key:t.key,title:t.title,target:t.target,source_quest:q.key,description:q.description,details:JP_RULES.multiChecklists[t.key]?JP_RULES.multiChecklists[t.key].entries:t.key==='fish:species'?JP_RULES.fishing.items.map(function(item){return {key:'fish:'+item,title:item.split(':')[1].replace(/_/g,' '),target:1};}):t.key==='dungeon:types'?Object.keys(JP_RULES.dungeons).map(function(type){return {key:'dungeon:'+type,title:type.replace(/_/g,' '),target:1};}):t.key==='diet:foods'?JP_RULES.dietFoods.map(function(food){return {key:'diet:'+food,title:jpFoodLabel(food),target:1};}):[]};})};
});
PlayerEvents.tick(function(event){
  if(!JournalBridgeClass||event.player.tickCount%20!==0)return;
  try {
    JournalBridgeClass.publish(String(event.player.uuid),jpJournalSnapshot(event.player));
  } catch(error) {
    if(!JournalBridgeFailed){JournalBridgeFailed=true;console.error('[ProgressionJournal] '+error);}
  }
});
function jpJournalSnapshot(player){
  var view=jpChecklistView(player),personal=jpPlayer(player),active={};
  JournalQuestRules.forEach(function(q){active[q.key]=JP.active(personal,q.key);});
  var quests=JournalQuestCards.map(function(card){
    if(!personal.done[card.goal]||!personal.rewards||!personal.rewards[card.goal])return card;
    var copy={};Object.keys(card).forEach(function(key){copy[key]=card[key];});copy.rewardXp=Number(personal.rewards[card.goal]);return copy;
  });
  var snapshot={schema:1,available:true,unlocks:view.unlocks,counts:view.counts,done:view.done,active:active,cards:jpEquipmentRewardCards(personal).concat(quests)};
  if(OptionalDifficultyAttachments)snapshot.difficulty=jpDifficulty(player);
  return JSON.stringify(snapshot);
}
// JOURNAL BRIDGE END

// Personal mining provenance. Appended to the authoritative adapter scope.
var MiningLevel=Java.loadClass('net.minecraft.server.level.ServerLevel');
var MiningPriority=Java.loadClass('net.neoforged.bus.api.EventPriority');
var MiningPlace=Java.loadClass('net.neoforged.neoforge.event.level.BlockEvent$EntityPlaceEvent');
var MiningPiston=Java.loadClass('net.neoforged.neoforge.event.level.PistonEvent$Pre');
function miningExclude(level,pos){
  if(!(level instanceof MiningLevel))return;
  jpLoad(level.getServer());
  if(!JP_DB.oreHistory)JP_DB.oreHistory={};
  var key=jpPos(level,pos);
  if(!JP_DB.oreHistory[key]){JP_DB.oreHistory[key]=true;JP_DIRTY=true;}
  if(!JP_DB.questBlockHistory)JP_DB.questBlockHistory={};
  if(!JP_DB.questBlockHistory[key]){JP_DB.questBlockHistory[key]=true;JP_DIRTY=true;}
}
function miningPlaced(level,pos){
  if(!(level instanceof MiningLevel))return;
  if(JP_RULES.mining.ores[String(level.getBlockState(pos).block.id)]||JP_RULES.optional.blocks.indexOf(String(level.getBlockState(pos).block.id))>=0)miningExclude(level,pos);
}
NativeEvents.onEvent(MiningPriority.LOWEST,MiningPlace,function(event){
  if(event.isCanceled())return;
  // Includes creative placement and fake-player/automation placement, not just survival players.
  miningPlaced(event.getLevel(),event.getPos());
  if(event instanceof Java.loadClass('net.neoforged.neoforge.event.level.BlockEvent$EntityMultiPlaceEvent')){
    event.getReplacedBlockSnapshots().forEach(function(snapshot){miningPlaced(event.getLevel(),snapshot.getPos());});
  }
});
NativeEvents.onEvent(MiningPriority.LOWEST,MiningPiston,function(event){
  if(event.isCanceled()||!(event.getLevel() instanceof MiningLevel))return;
  var resolver=event.getStructureHelper();
  if(!resolver||!resolver.resolve())return;
  var direction=String(event.getPistonMoveType())==='EXTEND'?event.getDirection():event.getDirection().getOpposite();
  resolver.getToPush().forEach(function(pos){
    if(JP_RULES.mining.ores[String(event.getLevel().getBlockState(pos).block.id)]||JP_RULES.optional.blocks.indexOf(String(event.getLevel().getBlockState(pos).block.id))>=0){
      // Moved ore is no longer untouched world generation; never launder it through pistons.
      miningExclude(event.getLevel(),pos);miningExclude(event.getLevel(),pos.relative(direction));
    }
  });
});


// Personal fishing and breeding evidence; appended to the authoritative adapter scope.
var SideGoalPriority=Java.loadClass('net.neoforged.bus.api.EventPriority');
var SideGoalFishing=Java.loadClass('net.neoforged.neoforge.event.entity.player.ItemFishedEvent');
var SideGoalBirth=Java.loadClass('net.neoforged.neoforge.event.entity.living.BabyEntitySpawnEvent');
NativeEvents.onEvent(SideGoalPriority.LOWEST,SideGoalFishing,function(event){
  var player=event.getEntity();
  if(!(player instanceof JP_Player)||event.isCanceled())return;
  var cast=String(event.getHookEntity().uuid),count=0,fishItems={};
  event.getDrops().forEach(function(stack){if(JP_RULES.fishing.items.indexOf(String(stack.id))>=0){count+=Number(stack.getCount());fishItems[String(stack.id)]=(fishItems[String(stack.id)]||0)+Number(stack.getCount());}});
  if(count<=0)return;
  player.server.scheduleInTicks(1,function(){
    if(!event.isCanceled())jpApply(player,{type:'fish',personal:true,castId:cast,count:count,items:fishItems});
  });
});
NativeEvents.onEvent(SideGoalPriority.LOWEST,SideGoalBirth,function(event){
  var player=event.getCausedByPlayer();
  if(!(player instanceof JP_Player)||event.isCanceled())return;
  player.server.scheduleInTicks(1,function(){
    var child=event.getChild();
    if(event.isCanceled()||!child||!child.isAlive()||child.isRemoved()||!child.level.getEntity(child.getId()))return;
    jpApply(player,{type:'breed',personal:true,mob:String(child.type),childId:String(child.uuid)});
  });
});


// Optional evidence and one-time XP payouts. Same authoritative adapter scope.
var OptionalTradeEvent=Java.loadClass('net.neoforged.neoforge.event.entity.player.TradeWithVillagerEvent');
var OptionalGrowEvent=Java.loadClass('net.neoforged.neoforge.event.level.BlockGrowFeatureEvent');
var OptionalLevel=Java.loadClass('net.minecraft.server.level.ServerLevel');
var OptionalPriority=Java.loadClass('net.neoforged.bus.api.EventPriority');
var OptionalDifficultyAttachments=null;
if(Platform.isLoaded('improvedmobs'))OptionalDifficultyAttachments=Java.loadClass('io.github.flemmli97.improvedmobs.common.registry.ImprovedMobsAttachments');
var OptionalTradeSession=String(Java.loadClass('java.util.UUID').randomUUID());
function jpDifficulty(player){if(!OptionalDifficultyAttachments)return undefined;return Number(OptionalDifficultyAttachments.PLAYER_DIFFICULTY.get().get(player).getDifficultyLevel());}
function jpOptionalRewards(player,state){
  if(!(player instanceof JP_Player)||player.isCreative()||player.isSpectator())return;
  if(!state.rewards)state.rewards={};
  JP_RULES.quests.forEach(function(q){
    if(!q.rewardXp||!state.done[q.key])return;
    var marker='jake_quest_reward_'+q.key;
    if(!player.persistentData.getBoolean(marker)){
      // XP and marker are saved together in the same vanilla player-data file.
      // If the progression JSON is replayed after restart, this marker still prevents a duplicate payout.
      player.giveExperiencePoints(Number(q.rewardXp));
      player.persistentData.putBoolean(marker,true);
      Java.loadClass('dev.jake.progression.QuestRewardPersistence').saveRewardPlayer(player);
      player.tell(Text.of('Quest complete: '+q.title+' | +'+q.rewardXp+' XP'));
    }
    if(!state.rewards[q.key]){state.rewards[q.key]=Number(q.rewardXp);JP_DIRTY=true;}
  });
}
NativeEvents.onEvent(OptionalPriority.LOWEST,OptionalTradeEvent,function(event){
  var player=event.getEntity(),merchant=event.getAbstractVillager();
  if(!(player instanceof JP_Player)||String(merchant.type)!=='minecraft:villager')return;
  var offer=event.getMerchantOffer(),proof=OptionalTradeSession+'|'+String(merchant.uuid)+'|'+String(player.uuid)+'|'+JP_TICK+'|'+String(offer)+'|'+String(offer.getUses());
  jpApply(player,{type:'trade',personal:true,merchant:String(merchant.uuid),tradeId:proof,emeralds:String(offer.getResult().id)==='minecraft:emerald'?Number(offer.getResult().count):0});
});
BlockEvents.placed(function(event){
  if(!(event.player instanceof JP_Player)||!event.block.hasTag('minecraft:saplings'))return;
  var player=event.player,level=player.level,pos=event.block.pos.immutable(),key=jpPos(level,pos);
  event.server.scheduleInTicks(1,function(){if(level.getBlock(pos).hasTag('minecraft:saplings'))jpApply(player,{type:'plantTree',pos:key});});
});
NativeEvents.onEvent(OptionalPriority.LOWEST,OptionalGrowEvent,function(event){
  var level=event.getLevel();if(event.isCanceled()||!(level instanceof OptionalLevel))return;
  jpLoad(level.getServer());var pos=event.getPos().immutable(),key=jpPos(level,pos);
  if(!JP_DB.saplings||!JP_DB.saplings[key])return;
  var owner=JP_DB.saplings[key].owner;
  level.getServer().scheduleInTicks(1,function(){
    if(event.isCanceled()||!level.getBlock(pos).hasTag('minecraft:logs'))return;
    var player=level.getServer().getPlayer(owner);
    if(player)jpApply(player,{type:'growTree',pos:key});
    else {JP.act(JP_DB,owner,{type:'growTree',pos:key});JP_DIRTY=true;}
  });
});
function jpOptionalVisits(player,state){
  var found=[];
  Object.keys(JP_RULES.optional.structures).forEach(function(key){
    if(JP.progress(state,'visit:'+key)>0)return;
    var ids=JP_RULES.optional.structures[key];
    var yes=ids.some(function(id){return jpStructure(player,id,false);});
    if(!yes&&key==='treasure'){
      var structure=player.level.registryAccess().registryOrThrow(JP_Registries.STRUCTURE).get(JP_RL.parse(ids[0]));
      if(structure){
        for(var offset=-3;offset<=1;offset++){
          if(player.level.structureManager()['getStructureWithPieceAt(net.minecraft.core.BlockPos,net.minecraft.world.level.levelgen.structure.Structure)'](player.blockPosition().offset(0,offset,0),structure).isValid()){yes=true;break;}
        }
      }
    }
    if(yes)found.push(key);
  });
  return found;
}




// Dungeon proof is captured before removal and credited only after the block is actually gone.
function jpDungeonAt(level,pos){
  jpLoad(level.server);
  if(JP_DB.oreHistory&&JP_DB.oreHistory[jpPos(level,pos)])return null;
  var keys=Object.keys(JP_RULES.dungeons||{});
  for(var i=0;i<keys.length;i++){
    var key=keys[i],structure=level.registryAccess().registryOrThrow(JP_Registries.STRUCTURE).get(JP_RL.parse(JP_RULES.dungeons[key]));
    if(!structure)continue;
    var start=level.structureManager()['getStructureWithPieceAt(net.minecraft.core.BlockPos,net.minecraft.world.level.levelgen.structure.Structure)'](pos,structure);
    if(start.isValid())return {key:key,start:start,proof:String(level.dimension)+'|'+String(start.getChunkPos())};
  }
  return null;
}
function jpDungeonCredit(breaker,level,pos,proof){
  breaker.server.playerList.players.forEach(function(player){
    if(!jpDungeonEligible(player,level,pos,proof))return;
    jpApply(player,{type:'dungeon',valid:true,dungeon:proof.key,proof:proof.proof});
  });
}
function jpDungeonEligible(player,level,pos,proof){
  var radius=Number(JP_RULES.dungeonCreditRadius||32);
  return String(player.level.dimension)===String(level.dimension)&&!player.isSpectator()&&!player.isCreative()&&player.distanceToSqr(pos.getX()+0.5,pos.getY()+0.5,pos.getZ()+0.5)<=radius*radius;
}
function jpFoodLabel(food){
  return ({beef:'Raw beef',cooked_beef:'Steak',porkchop:'Raw porkchop',chicken:'Raw chicken',mutton:'Raw mutton',rabbit:'Raw rabbit',cod:'Raw cod',salmon:'Raw salmon'})[food]||food.replace(/_/g,' ');
}
function jpDietFoods(player){
  var advancement=player.server.getAdvancements().get(JP_RL.parse('minecraft:husbandry/balanced_diet'));
  if(!advancement)return [];
  var progress=player.getAdvancements().getOrStartProgress(advancement),foods=[];

  (JP_RULES.dietFoods||[]).forEach(function(food){var criterion=progress.getCriterion(food);if(criterion&&criterion.isDone())foods.push(food);});
  return foods;
}
// A player-placed spawner never becomes an original dungeon spawner.
BlockEvents.placed(function(event){
  if(String(event.block.id)!=='minecraft:spawner')return;
  jpLoad(event.server);miningExclude(event.level,event.block.pos);
});



// Read proof from this authenticated player's vanilla advancements and current effects.
function jpUpdateMultiChecklists(player,state){
  var effects={};
  player.getActiveEffects().forEach(function(effect){var key=effect.getEffect().unwrapKey();if(key.isPresent())effects[String(key.get().location())]=true;});
  Object.keys(JP_RULES.multiChecklists||{}).forEach(function(key){
    var spec=JP_RULES.multiChecklists[key],holder=player.server.getAdvancements().get(JP_RL.parse(spec.advancement));
    if(!holder)return;
    var progress=player.getAdvancements().getOrStartProgress(holder),completed=progress.isDone(),count=0;
    spec.entries.forEach(function(entry){
      var criterion=spec.mode==='criteria'?progress.getCriterion(entry.criterion):null;
      var done=completed||(spec.mode==='criteria'?criterion&&criterion.isDone():!!effects[entry.criterion]);
      state.counts[entry.key]=done?1:0;if(done)count++;
    });
    state.counts[key]=count;
  });
}


// Cosmetic advancement notifications. These never authorize equipment use.
var JP_TIER_TOASTS=JSON.parse(JsonIO.readString('kubejs/config/tier_toast_advancements.json'));
var JP_TASK_NOTICE_DATA=JSON.parse(JsonIO.readString('kubejs/config/journal_task_advancements.json'));
var JP_TASK_TOASTS=Array.isArray(JP_TASK_NOTICE_DATA)?JP_TASK_NOTICE_DATA:JP_TASK_NOTICE_DATA.goals;
var JP_NOTICE_REVISION=Array.isArray(JP_TASK_NOTICE_DATA)?'initial':JP_TASK_NOTICE_DATA.revision;
function jpNoticeGoalComplete(state,goal){
  if(goal.quest)return !!state.done[goal.quest];
  return goal.eligible.some(function(stage){return !!state.unlocks[stage];})&&JP.progress(state,goal.key)>=goal.target;
}
function jpPrepareJournalNotices(state){
  if(state.journalNoticesInitialized&&state.journalNoticeRevision===JP_NOTICE_REVISION)return;
  if(!state.seenJournalNotices)state.seenJournalNotices={};
  // Installing the feature must not replay every historical completed checkbox.
  JP_TASK_TOASTS.forEach(function(goal){if(jpNoticeGoalComplete(state,goal))state.seenJournalNotices[goal.id]=true;});
  state.journalNoticesInitialized=true;
  state.journalNoticeRevision=JP_NOTICE_REVISION;
}
function jpTierUnlockNotices(player,state,previous){
  if(!state.pendingTierNotices)state.pendingTierNotices={};
  Object.keys(state.unlocks).forEach(function(key){
    if(state.unlocks[key]&&!previous[key]&&JP_TIER_TOASTS[key])state.pendingTierNotices[key]=true;
  });
  if(!state.pendingJournalNotices)state.pendingJournalNotices={};
  if(!state.seenJournalNotices)state.seenJournalNotices={};
  var freshByAction={};
  JP_TASK_TOASTS.forEach(function(goal){
    if(!state.seenJournalNotices[goal.id]&&jpNoticeGoalComplete(state,goal)){
      state.seenJournalNotices[goal.id]=true;
      var earlier=freshByAction[goal.key];
      // If the same action satisfies several page targets at once, announce the highest one once.
      if(!earlier||goal.target>earlier.target)freshByAction[goal.key]=goal;
    }
  });
  Object.keys(freshByAction).forEach(function(key){var goal=freshByAction[key];state.pendingJournalNotices[goal.id]=true;});
  var pending=Object.keys(state.pendingTierNotices),tasks=Object.keys(state.pendingJournalNotices);if(!pending.length&&!tasks.length)return;
  try{
    var root=player.server.getAdvancements().get(JP_RL.parse('kubejs:progression/root'));
    if(!root)throw new Error('Missing progression advancement root');
    player.getAdvancements().award(root,'unlock');
    var completed=[],completedTasks=[];
    tasks.forEach(function(id){
      var advancement=player.server.getAdvancements().get(JP_RL.parse(id));
      if(!advancement)throw new Error('Missing journal advancement '+id);
      if(!player.getAdvancements().getOrStartProgress(advancement).isDone())player.getAdvancements().award(advancement,'unlock');
      if(player.getAdvancements().getOrStartProgress(advancement).isDone())completedTasks.push(id);
    });
    pending.forEach(function(key){
      var id=JP_TIER_TOASTS[key];if(!id)return;
      var advancement=player.server.getAdvancements().get(JP_RL.parse(id));
      if(!advancement)throw new Error('Missing tier advancement '+id);
      if(!player.getAdvancements().getOrStartProgress(advancement).isDone())player.getAdvancements().award(advancement,'unlock');
      if(player.getAdvancements().getOrStartProgress(advancement).isDone())completed.push(key);
    });
    // Save the native per-player advancement markers before clearing pending deliveries.
    player.getAdvancements().save();
    completed.forEach(function(key){delete state.pendingTierNotices[key];});
    completedTasks.forEach(function(id){delete state.pendingJournalNotices[id];});
  }catch(error){jpError('tier notification',error);}
}


// One durable receipt per personal equipment goal; optional quests use their own payouts.
var JP_TASK_XP_DATA=JSON.parse(JsonIO.readString('kubejs/config/task_xp_rewards.json'));
var JP_TASK_XP_GOALS=JP_TASK_XP_DATA.goals;
var JP_TASK_XP_BY_KEY={};
var JP_TASK_XP_BY_ID={},JP_TASK_XP_RECEIPTS_CHECKED={};
JP_TASK_XP_GOALS.forEach(function(goal){JP_TASK_XP_BY_KEY[goal.key+'|'+goal.target]=goal;JP_TASK_XP_BY_ID[goal.id]=goal;});
function jpTaskXpComplete(state,goal){return goal.eligible.some(function(stage){return !!state.unlocks[stage];})&&JP.progress(state,goal.key)>=goal.target;}
function jpPrepareTaskRewards(state){
  if(!state.taskRewards)state.taskRewards={};
  if(state.taskRewardsInitialized&&state.taskRewardRevision===JP_TASK_XP_DATA.revision)return;
  // Adding rewards must not back-pay all goals completed before this update.
  JP_TASK_XP_GOALS.forEach(function(goal){if(state.taskRewards[goal.id]===undefined&&jpTaskXpComplete(state,goal))state.taskRewards[goal.id]=0;});
  state.taskRewardsInitialized=true;state.taskRewardRevision=JP_TASK_XP_DATA.revision;JP_DIRTY=true;
}
function jpGrantTaskRewards(player,state){
  if(!(player instanceof JP_Player)||player.isCreative()||player.isSpectator())return;
  var uuid=String(player.uuid);
  if(!JP_TASK_XP_RECEIPTS_CHECKED[uuid]){
    player.persistentData.getAllKeys().forEach(function(raw){
      var key=String(raw);if(key.indexOf('jake_task_reward_')!==0)return;
      var id=key.substring(17),paid=Number(player.persistentData.getInt(key));
      if(JP_TASK_XP_BY_ID[id]&&paid>0){state.taskRewards[id]=paid;JP_DIRTY=true;}
    });
    JP_TASK_XP_RECEIPTS_CHECKED[uuid]=true;
  }
  JP_TASK_XP_GOALS.forEach(function(goal){
    if(!jpTaskXpComplete(state,goal)||state.taskRewards[goal.id]!==undefined)return;
    var marker='jake_task_reward_'+goal.id,paid=Number(player.persistentData.getInt(marker));
    if(paid<=0){
      paid=Number(goal.rewardXp);
      player.giveExperiencePoints(paid);player.persistentData.putInt(marker,paid);
      Java.loadClass('dev.jake.progression.QuestRewardPersistence').saveRewardPlayer(player);
      player.tell(Text.of('Task complete: '+goal.title+' | +'+paid+' XP'));
    }
    // The integer receipt recovers the actual amount even if JSON is replayed later.
    state.taskRewards[goal.id]=paid;JP_DIRTY=true;
  });
}
function jpEquipmentRewardCards(state){
  return ChecklistPages.map(function(card){
    var copy={};Object.keys(card).forEach(function(key){copy[key]=card[key];});
    copy.tasks=card.tasks.map(function(task){
      var row={};Object.keys(task).forEach(function(key){row[key]=task[key];});
      var goal=JP_TASK_XP_BY_KEY[task.key+'|'+task.target];
      if(goal){var paid=state.taskRewards&&state.taskRewards[goal.id];row.rewardXp=paid===undefined?goal.rewardXp:Number(paid);}
      return row;
    });return copy;
  });
}

