// Run before AStages' normal player-tick ejector. Never drop rejected armor.
var ArmorReturnPlayer=Java.loadClass('net.minecraft.server.level.ServerPlayer');
var ArmorReturnStack=Java.loadClass('net.minecraft.world.item.ItemStack');
var ArmorReturnPacket=Java.loadClass('net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket');
var ArmorReturnHolder=Java.loadClass('com.alessandro.astages.api.holder.AHolder');
var ArmorReturnManager=Java.loadClass('com.alessandro.astages.engine.ARestrictionManager');
var ArmorReturnPriority=Java.loadClass('net.neoforged.bus.api.EventPriority');
var ArmorReturnTick=Java.loadClass('net.neoforged.neoforge.event.tick.PlayerTickEvent$Pre');
var ArmorReturnResource=Java.loadClass('net.minecraft.world.level.storage.LevelResource');
var ArmorReturnTags=Java.loadClass('net.minecraft.nbt.TagParser');
var ArmorReturnDb=null,ArmorReturnFile=null,ArmorReturnError=false;
var ArmorReturnStats={returned:0,queued:0,restored:0,failed:0};
function armorReturnLoad(server){
  if(ArmorReturnDb)return;
  ArmorReturnFile=String(server.getWorldPath(ArmorReturnResource.ROOT))+'/locked-armor-returns.json';
  var raw=JsonIO.readString(ArmorReturnFile);
  ArmorReturnDb=raw&&raw!=='null'?JSON.parse(raw):{schema:1,players:{}};
  if(ArmorReturnDb.schema!==1||!ArmorReturnDb.players)throw new Error('Invalid locked-armor return queue; refusing to reset it.');
}
function armorReturnSave(){JsonIO.write(ArmorReturnFile,ArmorReturnDb);}
function armorReturnSlot(player,slot){player.connection.send(new ArmorReturnPacket(-2,0,slot,player.inventory.getItem(slot).copy()));}
function armorReturnEmpty(inventory){for(var i=0;i<36;i++)if(inventory.getItem(i).isEmpty())return i;return -1;}
function restoreWaitingArmor(player){
  armorReturnLoad(player.server);
  var key=String(player.uuid),waiting=ArmorReturnDb.players[key];
  if(!waiting||!waiting.length)return;
  var changed=false;
  while(waiting.length){
    var slot=armorReturnEmpty(player.inventory);if(slot<0)break;
    var stack=ArmorReturnStack.parseOptional(player.registryAccess(),ArmorReturnTags.parseTag(waiting[0]));
    if(stack.isEmpty())throw new Error('Invalid saved armor stack; preserving queue for recovery.');
    player.inventory.setItem(slot,stack);waiting.shift();changed=true;
    armorReturnSlot(player,slot);ArmorReturnStats.restored++;
  }
  if(changed){if(!waiting.length)delete ArmorReturnDb.players[key];armorReturnSave();}
}
function returnLockedArmor(player){
  armorReturnLoad(player.server);
  var inv=player.inventory,key=String(player.uuid);
  for(var source=36;source<40;source++){
    var stack=inv.getItem(source);
    if(stack.isEmpty()||ArmorReturnManager.ITEM_INSTANCE.getEquipmentRestriction(ArmorReturnHolder.serverAndPlayer(player),stack)===null)continue;
    var dest=armorReturnEmpty(inv),copy=stack.copy();
    if(dest>=0){
      inv.setItem(source,ArmorReturnStack.EMPTY);inv.setItem(dest,copy);
      armorReturnSlot(player,source);armorReturnSlot(player,dest);ArmorReturnStats.returned++;
      player.tell('That armor tier is locked. The item was returned to your inventory.');
    }else{
      // Serialize all components (enchantments, damage, names) before removing.
      if(!ArmorReturnDb.players[key])ArmorReturnDb.players[key]=[];
      ArmorReturnDb.players[key].push(String(copy.save(player.registryAccess())));
      armorReturnSave();
      inv.setItem(source,ArmorReturnStack.EMPTY);armorReturnSlot(player,source);ArmorReturnStats.queued++;
      player.tell('That armor tier is locked. Your inventory is full; the item is safely held until you free a slot.');
    }
  }
}
NativeEvents.onEvent(ArmorReturnPriority.HIGHEST,ArmorReturnTick,function(event){
  var player=event.entity;
  if(!(player instanceof ArmorReturnPlayer)||player.isCreative()||player.isSpectator())return;
  try{returnLockedArmor(player);restoreWaitingArmor(player);}
  catch(error){ArmorReturnStats.failed++;if(!ArmorReturnError){ArmorReturnError=true;console.error('[ArmorSafeReturn] '+error);}}
});


console.info('[ArmorSafeReturn] Inventory-safe rejection registered before AStages ejection.');
