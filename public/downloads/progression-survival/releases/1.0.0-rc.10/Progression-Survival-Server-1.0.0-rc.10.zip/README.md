# Progression Survival — server bundle

Minecraft 1.21.1 · NeoForge 21.1.264 · pack 1.0.0-rc.10

## Create a new server

1. Extract this entire ZIP to a permanent folder. Install **Java 21** if `java -version` does not report 21.
2. Read the [Minecraft EULA](https://aka.ms/MinecraftEULA).
3. Open PowerShell in the extracted folder. If you agree to the EULA, run:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Create-Server-Instance.ps1 -Name Friend-Test-001 -AcceptEula
   ```

4. Open `instances\Friend-Test-001`. Run `Start-Server.ps1 -Background` from PowerShell there. Wait for `Done` in `logs\latest.log`.
5. On the host computer, join `127.0.0.1:25568` with the matching client pack.

The script downloads and checks the pinned mods and NeoForge. It creates a new world, private administration password, Hard survival, and no whitelist. It refuses to overwrite an existing instance. Java 21 must be available on PATH, or pass `-CacheJavaDirectory` with a Java 21 installation folder. Optional cache parameters are documented by the script parameters.

## Internet access

Allow the game server through Windows Firewall and forward **TCP 25568** on your router to the host computer's local IP. Friends use your public address plus `:25568`. Never forward the administration port, **25578**. Router setup and an external friend connection still need verification on Jake's computer.

## Operate and preserve worlds

- `Server-Command.ps1 -Command 'list'` checks players through local administration.
- `Stop-Server.ps1` saves and stops safely. Wait for it to finish.
- Back up the entire instance privately while stopped before changing it.
- Choose a new instance name for a fresh world. Do not delete a prior instance to reuse its name.
- Do not share `server.properties`, world folders, player data or private backups.

## Updating

Keep the world separate from release payloads. Stop and back up the instance. Apply only reviewed configuration/custom-mod changes and the matching pinned third-party versions, then restart and verify. Do not run the fresh-instance creator over an existing world. UI or client-mod changes require friends to update their client pack and restart; server rule changes may only need the server update. This candidate does not include an automatic updater.

The custom rules and journal are bundled here. Third-party mods download from their publishers; their own licenses apply. No Minecraft binaries, Java runtime, worlds or passwords are shipped in this ZIP.
