// Pure rules engine. Minecraft event adapters live in server_scripts.
// Stored personal counters, not FTB team completion, authorize every unlock.
var JakeEngineFactory = function(rules) {
  var armorOrder=['leather','copper','iron','gold','diamond','netherite'];
  var toolOrder=['wood','stone','copper','iron','gold','diamond','netherite'];
  function fresh(){return {schema:1,players:{},crops:{}};}
  function person(db,id){
    if(!db.players[id])db.players[id]={counts:{},crafted:{},done:{},unlocks:{},biomes:{},plants:{},harvestPlots:{},name:''};
    return db.players[id];
  }
  function add(p,k,n){p.counts[k]=Math.min(100000,Number(p.counts[k]||0)+Number(n||1));}
  function starter(p){return !!(p.done.gather&&p.done.basic);}
  function miningMet(p,track,tier){
    var options=rules.mining&&rules.mining.gates[track][tier];
    return !options||options.some(function(option){return option.every(function(goal){return Number(p.counts['mined:'+goal.material]||0)>=goal.target;});});
  }
  function allowed(p,track,tier){
    // Permanent historical stages survive this policy update without fabricated counts.
    if(p.unlocks[track+'_'+tier])return true;

    var side=rules.tierRequirements&&rules.tierRequirements[track]&&rules.tierRequirements[track][tier];
    if(side&&!side.every(function(key){return !!p.done[key];}))return false;
    if(track==='special')return !!p.unlocks.special_shield;
    var order=track==='armor'?armorOrder:toolOrder;
    if(track==='special'&&tier==='shield')return !!p.unlocks.special_shield;
    if(track==='armor'&&tier==='chainmail')return allowed(p,'armor','copper');
    var index=order.indexOf(tier);
    return index===0||index>0&&!!p.done[track+'_'+order[index-1]];
  }

  function active(p,key){
    if(key.indexOf('armor_')===0)return allowed(p,'armor',key.slice(6));
    if(key.indexOf('tools_')===0)return allowed(p,'tools',key.slice(6));
    if(key==='variety')return !!p.done.farm;
    if(key==='explore'||key==='practice'||key==='adv')return starter(p);
    if(key==='nether'||key==='adv_nether')return !!p.done.explore;
    if(key==='xp10')return !!p.counts.xp5;
    return true;
  }
  function countCrafted(p,track,tier){
    return rules[track][tier].items.filter(function(it){return Number(p.crafted[it]||0)>0;}).length;
  }
  function progress(p,key){
    if(key==='dungeon:any')return Object.keys(p.clearedDungeons||{}).length;
    if(key==='dungeon:types'){var types={};Object.keys(p.clearedDungeons||{}).forEach(function(proof){var type=proof.split('|')[0];if(rules.dungeons[type])types[type]=true;});return Object.keys(types).length;}
    if(key.indexOf('craft:')===0)return Math.max(Number(p.counts[key]||0),Number(p.crafted[key.slice(6)]||0));
    if(key==='feast:netherite:advanced_meals')return (rules.feastFoods||[]).filter(function(item){return Number(p.counts['stage:netherite:craft:'+item]||0)>0;}).length;
    if(key==='diet:foods')return Object.keys(p.dietFoods||{}).length;
    if(key.indexOf('diet:')===0)return p.dietFoods&&p.dietFoods[key.slice(5)]?1:0;
    if(key.indexOf('crafted:')===0){var bits=key.split(':');return countCrafted(p,bits[1],bits[2]);}
    if(key==='biomes')return Object.keys(p.biomes).length;
    if(key==='mid_armor')return p.done.armor_copper?1:0;
    if(key==='plant:wheat')return Number(p.counts['plant:wheat']===undefined?Object.keys(p.plants.wheat||{}).length:p.counts['plant:wheat']);
    if(key.indexOf('plant:')===0)return Object.keys(p.plants[key.slice(6)]||{}).length;
    if(key.indexOf('plots:')===0)return Object.keys(p.harvestPlots[key.slice(6)]||{}).length;
    if(key==='foundations')return starter(p)&&p.done.farm&&p.done.explore&&p.done.adv&&p.counts.xp5?1:0;
    return Number(p.counts[key]||0);
  }
  function currentToolTier(p){var tier='wood';toolOrder.forEach(function(t){if(allowed(p,'tools',t))tier=t;});return tier;}
  function prepareTierMining(p){
    if(!rules.mining.tierScoped||p.tierMiningVersion===1)return;
    var current=currentToolTier(p),currentIndex=toolOrder.indexOf(current),earlier={};
    toolOrder.forEach(function(tier,index){
      var quests=rules.quests.filter(function(q){return q.key==='tools_'+tier;});
      if(!quests.length)return;
      quests[0].tasks.forEach(function(task){
        if(task.key.indexOf('mined:'+tier+':')!==0)return;
        var material=task.key.split(':')[2],legacy=Number(p.counts['mined:'+material]||0);
        if(p.counts[task.key]===undefined){
          if(index<currentIndex&&p.done['tools_'+tier])p.counts[task.key]=Math.min(task.target,legacy);
          else if(index===currentIndex)p.counts[task.key]=earlier[material]&&rules.mining.legacyTierMigration!=='preserve_current'?0:legacy;
        }
        if(index<currentIndex)earlier[material]=true;
      });
    });
    p.tierMiningVersion=1;
  }
  function evaluate(p){
    prepareTierMining(p);
    for(var pass=0;pass<10;pass++){
      var changed=false;
      rules.quests.forEach(function(q){
        if(!p.done[q.key]&&active(p,q.key)&&q.tasks.every(function(t){return progress(p,t.key)>=t.target;})){
          p.done[q.key]=true;changed=true;
        }
      });
      if(!changed)break;
    }
    Object.keys(rules.armor).forEach(function(t){if(allowed(p,'armor',t))p.unlocks['armor_'+t]=true;});
    Object.keys(rules.tools).forEach(function(t){if(allowed(p,'tools',t))p.unlocks['tools_'+t]=true;});
    if(p.done.armor_iron||(allowed(p,'armor','iron')&&progress(p,'kill:iron:minecraft:skeleton')>=5))p.unlocks.special_shield=true;
    return p;
  }
  function itemInfo(item){return rules.items[item]||null;}
  function currentArmorTier(p){var tier='leather';armorOrder.forEach(function(t){if(allowed(p,'armor',t))tier=t;});return tier;}
  function fullArmor(items){
    if(!items||items.length!==4)return null;
    var seen={},tier=null;
    for(var i=0;i<items.length;i++){
      var m=itemInfo(items[i]);
      if(!m||m.track!=='armor'||(tier!==null&&tier!==m.tier)||seen[m.slot])return null;
      tier=m.tier;seen[m.slot]=true;
    }
    return tier;
  }
  function scoped(p,key,n){
    var tier=currentToolTier(p);
    if((rules.tierActionScopes[tier]||[]).indexOf(key)>=0){add(p,'stage:'+tier+':'+key,n);return true;}return false;
  }
  function weaponKind(e){
    if(e.ranged)return e.ranged;
    var meta=itemInfo(e.held);
    return meta&&['sword','axe'].indexOf(meta.slot)>=0?meta.slot:null;
  }
  // Optional challenges use genuine event evidence, not inventory possession.
  function optionalAct(db,id,p,e){
    if(!rules.optional)return;
    if(e.type==='excludeQuestBlock'&&e.pos){if(!db.questBlockHistory)db.questBlockHistory={};db.questBlockHistory[e.pos]=true;}
    if(e.type==='break'&&e.pos&&e.suitable&&rules.optional.blocks.indexOf(e.block)>=0){
      if(!db.questBlockHistory)db.questBlockHistory={};
      if(!db.questBlockHistory[e.pos]){add(p,'dig:'+e.block,1);scoped(p,'dig:'+e.block,1);db.questBlockHistory[e.pos]=true;}
    }
    if(e.type==='kill'&&e.personal&&rules.optional.hunts.indexOf(e.mob)>=0)add(p,'hunt:'+e.mob,1);
    if(e.type==='craft'&&Number(e.count)>0&&rules.optional.crafts.indexOf(e.item)>=0)add(p,'craftQuest:'+e.item,Number(e.count));
    if(e.type==='plantTree'&&e.pos&&progress(p,'trees:grown')<100){if(!db.saplings)db.saplings={};db.saplings[e.pos]={owner:id};}
    if(e.type==='growTree'&&e.pos&&db.saplings&&db.saplings[e.pos]&&db.saplings[e.pos].owner===id){
      if(progress(p,'trees:grown')<100)add(p,'trees:grown',1);delete db.saplings[e.pos];
    }
    if(e.type==='trade'&&e.personal&&e.merchant&&e.tradeId){
      if(!p.tradedVillagers)p.tradedVillagers={};
      if(Number(e.emeralds)>0){if(!db.emeraldTradeProofs)db.emeraldTradeProofs={};if(!db.emeraldTradeProofs[e.tradeId]){db.emeraldTradeProofs[e.tradeId]=true;add(p,'trade:emeralds',Number(e.emeralds));scoped(p,'trade:emeralds',Number(e.emeralds));}}
      var newMerchant=!p.tradedVillagers[e.merchant],needed=progress(p,'trade:deals')<100||(newMerchant&&progress(p,'trade:villagers')<20);
      if(needed){
        if(!db.tradeProofs)db.tradeProofs={};
        if(!db.tradeProofs[e.tradeId]){
          db.tradeProofs[e.tradeId]=true;
          if(progress(p,'trade:deals')<100)add(p,'trade:deals',1);
          if(newMerchant&&progress(p,'trade:villagers')<20){p.tradedVillagers[e.merchant]=true;add(p,'trade:villagers',1);}
        }
      }
    }
    if(e.type==='poll'){
      (e.structures||[]).forEach(function(key){if(rules.optional.structures[key])p.counts['visit:'+key]=1;});
    }
  }

  function act(db,id,e){
    var p=person(db,id),m,k,plant;
    evaluate(p);optionalAct(db,id,p,e);
    if(e.type==='fish'&&e.personal&&e.castId&&Number(e.count)>0){
      if(!db.fishingCasts)db.fishingCasts={};
      if(!db.fishingCasts[e.castId]){
        var changed=false,oldFish=progress(p,'fish:caught'),totalFish=Math.min(rules.fishing.maxCredit,oldFish+Number(e.count));
        if(scoped(p,'fish:caught',Number(e.count)))changed=true;
        if(totalFish!==oldFish){p.counts['fish:caught']=totalFish;changed=true;}
        Object.keys(e.items||{}).forEach(function(item){
          if(rules.fishing.items.indexOf(item)<0||Number(e.items[item])<=0)return;
          var key='fish:'+item,old=progress(p,key),cap=(item==='minecraft:cod'||item==='minecraft:salmon')?64:1;
          if(old<cap){if(old===0)add(p,'fish:species',1);p.counts[key]=Math.min(cap,old+Number(e.items[item]));changed=true;}
        });
        if(changed)db.fishingCasts[e.castId]=true;
      }
    }else if(e.type==='breed'&&e.personal&&e.childId&&rules.livestock[e.mob]){
      var breedKey='breed:'+e.mob;
      if(progress(p,breedKey)<rules.livestock[e.mob]){
        if(!db.breedingBirths)db.breedingBirths={};
        if(!db.breedingBirths[e.childId]){db.breedingBirths[e.childId]=true;add(p,breedKey,1);}
      }
    }else if(e.type==='excludeOre'){
      if(!db.oreHistory)db.oreHistory={};
      if(e.pos)db.oreHistory[e.pos]=true;
    }else if(e.type==='craft'||e.type==='cook'){
      scoped(p,'craft:'+e.item,Number(e.count));
      if((rules.requirementCrafts||[]).indexOf(e.item)>=0)add(p,'craft:'+e.item,e.count);
      m=itemInfo(e.item);
      if(m){
        // Waxing a borrowed piece never proves personally crafting that piece.
        if((m.track==='armor'||allowed(p,m.track,m.tier))&&!e.waxing)p.crafted[m.canonical]=Math.min(1000,(p.crafted[m.canonical]||0)+e.count);
      }else{

        if(e.item==='minecraft:bread')add(p,'bread',e.count);
      }
    }else if(e.type==='break'){
      var ore=rules.mining&&rules.mining.ores[e.block];
      if(ore&&e.pos&&e.suitable){
        if(!db.oreHistory)db.oreHistory={};
        if(!db.oreHistory[e.pos]){add(p,'mined:'+ore,1);if(rules.mining.tierScoped)add(p,'mined:'+currentToolTier(p)+':'+ore,1);db.oreHistory[e.pos]=true;}
      }
      if(e.log)add(p,'logs',1);
      if(e.block==='minecraft:stone'){add(p,'stone',1);if(active(p,'practice')&&!p.done.practice)add(p,'practice_stone',1);}
      m=itemInfo(e.held);
      if(m&&m.track==='tools'&&allowed(p,'tools',m.tier)){
        k=m.slot==='pickaxe'&&e.suitable?'mine':m.slot==='axe'&&e.log?'chop':m.slot==='shovel'&&e.soil?'dig':null;
        if(k)add(p,'use:'+currentToolTier(p)+':'+k,1);
      }
      plant=db.crops[e.pos];
      if(plant&&plant.owner===id&&plant.crop===e.crop&&e.mature&&(!!e.crop)){
        add(p,'harvest:'+e.crop,1);scoped(p,'harvest:'+e.crop,1);
        if(!p.harvestPlots[e.crop])p.harvestPlots[e.crop]={};
        p.harvestPlots[e.crop][e.pos]=true;
      }
      if(e.pos)delete db.crops[e.pos];
    }else if(e.type==='plant'){
      if(!!e.crop){
        if(!db.crops[e.pos]||db.crops[e.pos].owner!==id||db.crops[e.pos].crop!==e.crop)scoped(p,'plant:'+e.crop,1);
        if(e.crop==='wheat'&&(!db.crops[e.pos]||db.crops[e.pos].owner!==id||db.crops[e.pos].crop!==e.crop)){
          if(p.counts['plant:wheat']===undefined)p.counts['plant:wheat']=Object.keys(p.plants.wheat||{}).length;
          add(p,'plant:wheat',1);
        }
        if(!p.plants[e.crop])p.plants[e.crop]={};
        p.plants[e.crop][e.pos]=true;
        db.crops[e.pos]={owner:id,crop:e.crop};
      }
    }else if(e.type==='invalidateCrop'){
      delete db.crops[e.pos];
    }else if(e.type==='till'){
      m=itemInfo(e.held);
      if(m&&m.track==='tools'&&m.slot==='hoe'&&allowed(p,'tools',m.tier))add(p,'use:'+currentToolTier(p)+':till',1);
    }else if(e.type==='kill'&&e.personal){
      var tier=currentArmorTier(p),kind=weaponKind(e),meta=itemInfo(e.held);
      var validWeapon=e.ranged?((e.ranged==='bow'&&allowed(p,'armor','copper'))||(e.ranged==='crossbow'&&allowed(p,'armor','iron'))):(!meta||allowed(p,meta.track,meta.tier));
      var eligible=fullArmor(e.armor)===tier&&rules.armor[tier].items.every(function(item){return Number(p.crafted[item]||0)>0||(e.earnedArmor||[]).indexOf(item)>=0;})&&validWeapon;
      if(eligible){
        if(rules.armor[tier].kills[e.mob])add(p,'kill:'+tier+':'+e.mob,1);
        if(e.hostile&&kind){
          add(p,'weapon:'+tier+':'+kind,1);
          if(tier==='copper'&&kind==='bow'||tier==='iron'&&kind==='crossbow')add(p,'ranged:'+tier,1);
        }
      }
    }else if(e.type==='shieldBlock'&&e.arrow&&e.projectile&&allowed(p,'special','shield')){
      if(!p.blockedArrows)p.blockedArrows={};
      if(!p.blockedArrows[e.projectile]){p.blockedArrows[e.projectile]=true;add(p,'shield:arrows_blocked',1);}
    }else if(e.type==='bountyPoll'&&e.available){
      p.counts['bounties:completed']=Math.max(progress(p,'bounties:completed'),Math.max(0,Number(e.completed)||0));
    }else if(e.type==='dungeon'&&e.valid&&rules.dungeons[e.dungeon]&&e.proof){
      if(!p.clearedDungeons)p.clearedDungeons={};
      var proof=e.dungeon+'|'+e.proof;if(!p.clearedDungeons[proof]){p.clearedDungeons[proof]=true;add(p,'dungeon:'+e.dungeon,1);var tier='leather';armorOrder.forEach(function(t){if(p.unlocks['armor_'+t])tier=t;});if(armorOrder.indexOf(tier)>=2)add(p,'dungeon:tier:'+tier,1);}
    }else if(e.type==='poll'){
      if(e.dietFoods){if(!p.dietFoods)p.dietFoods={};e.dietFoods.forEach(function(food){if(rules.dietFoods.indexOf(food)>=0)p.dietFoods[food]=true;});}
      if(active(p,'explore')&&e.dimension==='minecraft:overworld'&&e.biome){
        p.biomes[e.biome]=true;
        if(Object.keys(p.biomes).length>=3&&e.village)p.counts.village=1;
      }
      if(active(p,'nether')&&e.dimension==='minecraft:the_nether'){
        p.counts.nether=1;if(e.fortress)p.counts.fortress=1;
      }
      if(active(p,'practice')&&e.xp>=5)p.counts.xp5=1;
      if(active(p,'xp10')&&e.xp>=10)p.counts.xp10=1;
      if(e.coal>=8)p.counts.coal=8;
      (e.advancements||[]).forEach(function(a){
        if((rules.optional&&rules.optional.advancements.indexOf(a)>=0)||a==='minecraft:story/enchant_item'||a==='minecraft:end/kill_dragon'||(a==='minecraft:story/enter_the_nether'&&active(p,'adv_nether'))||(a!=='minecraft:story/enter_the_nether'&&active(p,'adv')))p.counts['adv:'+a]=1;
      });
    }
    evaluate(p);return p;
  }
  return {fresh:fresh,person:person,allowed:allowed,active:active,progress:progress,evaluate:evaluate,act:act,itemInfo:itemInfo,fullArmor:fullArmor};
};
if(typeof global!=='undefined')global.JakeEngineFactory=JakeEngineFactory;
if(typeof module!=='undefined')module.exports=JakeEngineFactory;
