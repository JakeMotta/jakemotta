// Run before AStages' normal player-tick ejector. Never drop rejected armor.
var ArmorReturnPlayer=Java.loadClass('net.minecraft.server.level.ServerPlayer');
var ArmorReturnStack=Java.loadClass('net.minecraft.world.item.ItemStack');
var ArmorReturnPacket=Java.loadClass('net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket');
var ArmorReturnHolder=Java.loadClass('com.alessandro.astages.api.holder.AHolder');
var ArmorReturnManager=Java.loadClass('com.alessandro.astages.engine.ARestrictionManager');
var ArmorReturnPriority=Java.loadClass('net.neoforged.bus.api.EventPriority');
var ArmorReturnTick=Java.loadClass('net.neoforged.neoforge.event.tick.PlayerTickEvent$Pre');
var ArmorReturnResource=Java.loadClass('net.minecraft.world.level.storage.LevelResource');
var ArmorReturnTags=Java.loadClass('net.minecraft.nbt.TagParser');
var ArmorReturnDb=null,ArmorReturnFile=null,ArmorReturnError=false;
var ArmorReturnStats={returned:0,queued:0,restored:0,failed:0};
function armorReturnLoad(server){
  if(ArmorReturnDb)return;
  ArmorReturnFile=String(server.getWorldPath(ArmorReturnResource.ROOT))+'/locked-armor-returns.json';
  var raw=JsonIO.readString(ArmorReturnFile);
  ArmorReturnDb=raw&&raw!=='null'?JSON.parse(raw):{schema:1,players:{}};
  if(ArmorReturnDb.schema!==1||!ArmorReturnDb.players)throw new Error('Invalid locked-armor return queue; refusing to reset it.');
}
function armorReturnSave(){JsonIO.write(ArmorReturnFile,ArmorReturnDb);}
function armorReturnSlot(player,slot){player.connection.send(new ArmorReturnPacket(-2,0,slot,player.inventory.getItem(slot).copy()));}
function armorReturnEmpty(inventory){for(var i=0;i<36;i++)if(inventory.getItem(i).isEmpty())return i;return -1;}
function restoreWaitingArmor(player){
  armorReturnLoad(player.server);
  var key=String(player.uuid),waiting=ArmorReturnDb.players[key];
  if(!waiting||!waiting.length)return;
  var changed=false;
  while(waiting.length){
    var slot=armorReturnEmpty(player.inventory);if(slot<0)break;
    var stack=ArmorReturnStack.parseOptional(player.registryAccess(),ArmorReturnTags.parseTag(waiting[0]));
    if(stack.isEmpty())throw new Error('Invalid saved armor stack; preserving queue for recovery.');
    player.inventory.setItem(slot,stack);waiting.shift();changed=true;
    armorReturnSlot(player,slot);ArmorReturnStats.restored++;
  }
  if(changed){if(!waiting.length)delete ArmorReturnDb.players[key];armorReturnSave();}
}
function returnLockedArmor(player){
  armorReturnLoad(player.server);
  var inv=player.inventory,key=String(player.uuid);
  for(var source=36;source<40;source++){
    var stack=inv.getItem(source);
    if(stack.isEmpty()||ArmorReturnManager.ITEM_INSTANCE.getEquipmentRestriction(ArmorReturnHolder.serverAndPlayer(player),stack)===null)continue;
    var dest=armorReturnEmpty(inv),copy=stack.copy();
    if(dest>=0){
      inv.setItem(source,ArmorReturnStack.EMPTY);inv.setItem(dest,copy);
      armorReturnSlot(player,source);armorReturnSlot(player,dest);ArmorReturnStats.returned++;
      player.tell('That armor tier is locked. The item was returned to your inventory.');
    }else{
      // Serialize all components (enchantments, damage, names) before removing.
      if(!ArmorReturnDb.players[key])ArmorReturnDb.players[key]=[];
      ArmorReturnDb.players[key].push(String(copy.save(player.registryAccess())));
      armorReturnSave();
      inv.setItem(source,ArmorReturnStack.EMPTY);armorReturnSlot(player,source);ArmorReturnStats.queued++;
      player.tell('That armor tier is locked. Your inventory is full; the item is safely held until you free a slot.');
    }
  }
}
NativeEvents.onEvent(ArmorReturnPriority.HIGHEST,ArmorReturnTick,function(event){
  var player=event.entity;
  if(!(player instanceof ArmorReturnPlayer)||player.isCreative()||player.isSpectator())return;
  try{returnLockedArmor(player);restoreWaitingArmor(player);}
  catch(error){ArmorReturnStats.failed++;if(!ArmorReturnError){ArmorReturnError=true;console.error('[ArmorSafeReturn] '+error);}}
});
ServerEvents.basicCommand('armorreturnstatus',function(event){event.respond(Text.of(JSON.stringify(ArmorReturnStats)));});
ServerEvents.basicCommand('armorreturnaudit',function(event){
  var results=[],player=null,key='15d7c816-776d-41d0-8cbb-90ecc8d13b51';
  function check(value,message){if(!value)throw new Error(message);}
  try{
    armorReturnLoad(event.server);if(ArmorReturnDb.players[key])throw new Error('Audit queue already occupied');
    var UUID=Java.loadClass('java.util.UUID'),Profile=Java.loadClass('com.mojang.authlib.GameProfile');
    var Info=Java.loadClass('net.minecraft.server.level.ClientInformation');
    var Factory=Java.loadClass('net.neoforged.neoforge.common.util.FakePlayerFactory');
    var profile=new Profile(UUID.fromString(key),'ArmorReturnAudit');
    player=new ArmorReturnPlayer(event.server,event.server.overworld(),profile,Info.createDefault());
    player.connection=Factory.get(event.server.overworld(),profile).connection;
    player.gameMode.changeGameModeForPlayer(Java.loadClass('net.minecraft.world.level.GameType').SURVIVAL);
    var armor=Item.of('minecraft:iron_chestplate');armor.setDamageValue(7);
    player.inventory.setItem(38,armor.copy());returnLockedArmor(player);
    check(player.inventory.getItem(38).isEmpty(),'Armor was not removed');
    check(String(player.inventory.getItem(0).id)==='minecraft:iron_chestplate','Armor was not returned to an inventory slot');
    check(player.inventory.getItem(0).getDamageValue()===7,'Armor damage was lost');
    results.push({name:'locked armor returns to inventory with metadata',passed:true});
    for(var i=0;i<36;i++)player.inventory.setItem(i,Item.of('minecraft:stone',64));
    player.inventory.setItem(38,armor.copy());returnLockedArmor(player);
    check(player.inventory.getItem(38).isEmpty(),'Full inventory left armor equipped');
    check(ArmorReturnDb.players[key].length===1,'Full inventory did not preserve armor in queue');
    var saved=JSON.parse(JsonIO.readString(ArmorReturnFile));check(saved.players[key].length===1,'Return queue was not saved');
    results.push({name:'full inventory preserves rejected armor in a saved queue',passed:true});
    player.inventory.setItem(5,ArmorReturnStack.EMPTY);restoreWaitingArmor(player);
    check(String(player.inventory.getItem(5).id)==='minecraft:iron_chestplate','Queued armor was not restored');
    check(player.inventory.getItem(5).getDamageValue()===7,'Queued armor lost metadata');
    check(!ArmorReturnDb.players[key],'Restored armor remained queued');
    results.push({name:'freeing an inventory slot restores queued armor exactly once',passed:true});
  }catch(error){results.push({name:'armor safe-return audit',passed:false,error:String(error)});}
  finally{if(player)player.inventory.clearContent();if(ArmorReturnDb&&ArmorReturnDb.players[key]){delete ArmorReturnDb.players[key];armorReturnSave();}}
  var report={results:results,failed:results.filter(function(r){return !r.passed;}).length,scope:'Synthetic native inventory and serialized stack checks; real shift-click retest still required'};
  JsonIO.write('armor-return-audit.json',report);event.respond(Text.of(JSON.stringify(report)));
});
console.info('[ArmorSafeReturn] Inventory-safe rejection registered before AStages ejection.');
