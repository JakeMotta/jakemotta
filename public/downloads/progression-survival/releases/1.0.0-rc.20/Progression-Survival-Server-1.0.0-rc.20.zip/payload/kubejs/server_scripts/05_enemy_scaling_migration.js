var ScalingJoin,ScalingEnemy,ScalingAttributes,ScalingModifier,ScalingOperation,ScalingFlags,ScalingExtra,ScalingId,ScalingPriority,ScalingServerLevel;
// One-time migration of saved Improved Mobs scaling, retaining spawn rank and current health fraction.
// Fresh spawns already use the current datapack. Only the exact former pack-owned curve is converted.
if(Platform.isLoaded('improvedmobs')){
 ScalingServerLevel=Java.loadClass('net.minecraft.server.level.ServerLevel');
 ScalingJoin=Java.loadClass('net.neoforged.neoforge.event.entity.EntityJoinLevelEvent');
 ScalingEnemy=Java.loadClass('net.minecraft.world.entity.monster.Enemy');
 ScalingAttributes=Java.loadClass('net.minecraft.world.entity.ai.attributes.Attributes');
 ScalingModifier=Java.loadClass('net.minecraft.world.entity.ai.attributes.AttributeModifier');
 ScalingOperation=Java.loadClass('net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation');
 ScalingFlags=Java.loadClass('io.github.flemmli97.improvedmobs.common.utils.EntityFlags');
 ScalingExtra=Java.loadClass('io.github.flemmli97.improvedmobs.common.utils.EntityFlags$ServerSideAttributes');
 ScalingId=Java.loadClass('io.github.flemmli97.improvedmobs.common.utils.Utils').ATTRIBUTE_ID;
 ScalingPriority=Java.loadClass('net.neoforged.bus.api.EventPriority');
 NativeEvents.onEvent(ScalingPriority.LOWEST,ScalingJoin,function(event){if(event.isCanceled())return;progressionMigrateEnemyScaling(event.getEntity(),event.loadedFromDisk());});
}

 function progressionMigrateEnemyScaling(mob,fromDisk){
  if(!(mob instanceof ScalingEnemy)||!(mob.level instanceof ScalingServerLevel)||!mob.isAlive()||mob.persistentData.getInt('jake_enemy_scaling_revision')>=1)return false;
  if(!fromDisk){mob.persistentData.putInt('jake_enemy_scaling_revision',1);return false;}
  var hp=mob.getAttribute(ScalingAttributes.MAX_HEALTH),attack=mob.getAttribute(ScalingAttributes.ATTACK_DAMAGE),healthMod=hp?hp.getModifier(ScalingId):null,attackMod=attack?attack.getModifier(ScalingId):null;
  var flags=ScalingFlags.get(mob),projectile=Number(flags.getAttribute(ScalingExtra.PROJECTILE_DAMAGE_MULTIPLIER)),explosion=Number(flags.getAttribute(ScalingExtra.EXPLOSION_DAMAGE_MULTIPLIER));
  if(!healthMod||String(healthMod.operation())!=='ADD_MULTIPLIED_BASE')return false;
  var oldHealth=Number(healthMod.amount()),fraction=oldHealth/5;
  if(fraction<0||fraction>1.000001||Math.abs(projectile-(1+2*fraction))>0.00001||Math.abs(explosion-(1+2*fraction))>0.00001)return false;
  if(attackMod&&(String(attackMod.operation())!=='ADD_MULTIPLIED_BASE'||Math.abs(Number(attackMod.amount())-3*fraction)>0.00001))return false;
  var healthFraction=Number(mob.getHealth())/Number(mob.getMaxHealth());
  hp['removeModifier(net.minecraft.resources.ResourceLocation)'](ScalingId);hp.addPermanentModifier(new ScalingModifier(ScalingId,2*fraction,ScalingOperation.ADD_MULTIPLIED_BASE));
  if(attackMod){attack['removeModifier(net.minecraft.resources.ResourceLocation)'](ScalingId);attack.addPermanentModifier(new ScalingModifier(ScalingId,fraction,ScalingOperation.ADD_MULTIPLIED_BASE));}
  flags.setAttribute(ScalingExtra.PROJECTILE_DAMAGE_MULTIPLIER,1+0.5*fraction);flags.setAttribute(ScalingExtra.EXPLOSION_DAMAGE_MULTIPLIER,1+0.5*fraction);
  mob.setHealth(Math.max(0.001,Math.min(1,healthFraction)*Number(mob.getMaxHealth())));
  mob.persistentData.putInt('jake_enemy_scaling_revision',1);return true;
 }
