// Correct client-predicted armor after AStages rejects right-click-in-air.
// Inventory contents and stage permissions are never changed here.
var ArmorSyncPlayer=Java.loadClass('net.minecraft.server.level.ServerPlayer');
var ArmorSyncPacket=Java.loadClass('net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket');
var ArmorSyncHolder=Java.loadClass('com.alessandro.astages.api.holder.AHolder');
var ArmorSyncManager=Java.loadClass('com.alessandro.astages.engine.ARestrictionManager');
var ArmorSyncPriority=Java.loadClass('net.neoforged.bus.api.EventPriority');
var ArmorSyncEvent=Java.loadClass('net.neoforged.neoforge.event.entity.player.PlayerInteractEvent$RightClickItem');
var ArmorSyncItems=JSON.parse(JsonIO.readString('kubejs/config/progression_rules.json')).items;
var ArmorSyncStats={scheduled:0,completed:0,failed:0};
function refreshArmorDisplay(player){
  var inventory=player.inventory;
  // -2 addresses the player's inventory directly, independent of open menus.
  // 36-39 are boots, legs, chest, head; 40 is offhand.
  var slots=[Number(inventory.selected),36,37,38,39,40];
  slots.forEach(function(slot){
    player.connection.send(new ArmorSyncPacket(-2,0,slot,inventory.getItem(slot).copy()));
  });
}
NativeEvents.onEvent(ArmorSyncPriority.HIGHEST,ArmorSyncEvent,function(event){
  var player=event.entity;
  if(!(player instanceof ArmorSyncPlayer))return;
  var info=ArmorSyncItems[String(event.itemStack.id)];
  if(!info||info.track!=='armor')return;
  if(ArmorSyncManager.ITEM_INSTANCE.getEquipmentRestriction(ArmorSyncHolder.serverAndPlayer(player),event.itemStack)===null)return;
  // Register before AStages' NORMAL handler cancels the event, then send the
  // authoritative slots after the canceled action and client prediction.
  ArmorSyncStats.scheduled++;
  player.server.scheduleInTicks(1,function(){
    try{refreshArmorDisplay(player);ArmorSyncStats.completed++;}
    catch(error){ArmorSyncStats.failed++;console.error('[ArmorDisplaySync] '+error);}
  });
});
ServerEvents.basicPublicCommand('refreshgear',function(event){
  if(!event.player){event.respond(Text.of('Player-only command.'));return;}
  refreshArmorDisplay(event.player);
  event.respond(Text.of('Equipment display refreshed. Your items and unlocks are unchanged.'));
});
ServerEvents.basicCommand('armorsyncstatus',function(event){
  event.respond(Text.of(JSON.stringify(ArmorSyncStats)));
});
console.info('[ArmorDisplaySync] Blocked armor right-click resynchronization registered.');
