param([switch]$Background)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
if((Get-Content -LiteralPath 'eula.txt') -notcontains 'eula=true'){throw 'Minecraft EULA agreement is required before starting.'}
$taskInstance=Get-Content -LiteralPath 'instance.json' -Raw | ConvertFrom-Json
foreach($taskPort in @($taskInstance.gamePort,$taskInstance.rconPort)){
 $taskProbe=[Net.Sockets.TcpClient]::new()
 try{if($taskProbe.ConnectAsync('127.0.0.1',[int]$taskPort).Wait(500)){throw ('Port '+$taskPort+' is already in use.')}}catch [AggregateException]{}finally{$taskProbe.Dispose()}
}
$taskJava=$taskInstance.javaPath
$taskLock=Get-Content -LiteralPath 'mods.lock.json' -Raw | ConvertFrom-Json
$taskArguments=@('@user_jvm_args.txt',('@libraries/net/neoforged/neoforge/'+$taskLock.neoforge+'/win_args.txt'),'nogui')
if($Background){
 $taskProcess=Start-Process -FilePath $taskJava -WorkingDirectory $PSScriptRoot -ArgumentList $taskArguments -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'console-output.log') -RedirectStandardError (Join-Path $PSScriptRoot 'console-error.log') -PassThru
 $taskProcess.Id | Set-Content -LiteralPath 'server.pid'
 Write-Output ('Server starting on game port '+$taskInstance.gamePort+'.')
}else{& $taskJava @taskArguments}
