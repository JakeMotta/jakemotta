Scott Pilgrim side-scroller
Jake Motta, CS 134 (game programming), San Jose State, March 2017
https://jakemotta.com/project/scott-pilgrim

HOW TO RUN

You need Java 8 or newer (https://adoptium.net).

Unzip the whole folder first, then either:
  - double-click scott-pilgrim.jar, or
  - open a terminal in this folder and run:  java -jar scott-pilgrim.jar

Run it from inside this folder. The game loads its sprites from the
Sprites folder next to it, by relative path, so if Java starts it from
anywhere else the window opens but Scott, Ramona and the ground are missing.
Keep lib/jogamp-fat.jar where it is too.

Tested on Windows 10 with Java 25. JOGL 2.3.2 also ships Linux and Intel Mac
libraries; on an Apple Silicon Mac it needs an Intel (x86_64) Java, and may
not start at all.

CONTROLS

  Arrow keys   run (left, right, up, down)
  Z            punch (and throw a fireball)
  Esc          quit

WHAT'S IN HERE

  scott-pilgrim.jar     the game, compiled in 2017
  lib/jogamp-fat.jar    JOGL 2.3.2 (OpenGL for Java), https://jogamp.org
  Sprites/              the sprites and tiles

CREDITS

Scott and Ramona are sprites from Scott Pilgrim vs. the World: The Game
(Ubisoft, 2010; art by Paul Robertson). The grass and dirt tiles are from
Super Mario World (Nintendo). This is a student project, not affiliated
with either.
