Coloris (2014) by Jake Motta, an unfinished Greenfoot RPG.

Needs Java 8 or newer (java.com). Keep the two jars together and open play-coloris.jar
(double-click it, or run: java -jar play-coloris.jar). Press Run under the game.

Arrow keys walk. 1 to 6 change Huey's color: 1 white, 2 black, 3 red, 4 green, 5 blue, 6 yellow.
There are no enemies, goals or sounds yet.

play-coloris.jar only starts the game at Greenfoot's normal speed; the game itself is coloris.jar.
