Thanks for your interest in Bubble Tanks Tower Defense and Hero Interactive!

This package is designed for anyone who would like to place the game Bubble Tanks Tower Defense by Hero Interactive on their website or is interested in reviewing the game.  I hope you find it helpful, please send me any suggestions if I forgot anything!

Contact Jared if you have any questions, concerns, or would like an interview:
jared@herointeractive.com

This game is already sponsored by:
Armor Games

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Bubble Tanks Tower Defense
by Hero Interactive, LLC

Short Description: Evolve your towers for epic win.

Description:

Bubble Tanks Tower Defense takes Hero's popular series into new genres and beyond!  With 7 enemy types, over 11 unique tower paths, tower merging allowing for mega towers and mega-mega towers (the size of 16 towers combined!), and 52 whopping game modes, we're pretty sure you'll have plenty to keep you busy until the release of Bubble Tanks Arenas. :)  If that's not enough for you, just check the "FML" checkbox from level select and prepare to get your world rocked... er... blocked.  

This has been a huge undertaking for Hero Interactive and we're proud to finally release the game.  A special thanks goes out to our fans for all of your support!


Controls:
Full tutorial and instructions are in game.  Can be played using only the mouse, but hotkeys are suggested for experienced players.  Hotkeys can be changed via the Settings menu.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Licensing Info:

You are free to put the .swf of Bubble Tanks Tower Defense up on your website, as is, for free.  You may not modify or try to restrict any of the features of the game. 

If you choose to host the game, please credit the game and link to:

Hero Interactive
http://www.herointeractive.com

If you are interested in licensing a special copy of the game, please contact us!

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

File Info:

File: BubbleTanksTowerDefense.swf
Version: Flash 10 / CS4 / AS3
Dimensions: 650x550 px	Note: Please use the original dimensions.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Other Notes:

* Some screenshots and sample icons are provided which you may use.









