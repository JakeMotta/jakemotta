param(
 [string]$Name='Friend-Test-001',
 [int]$Port=25568,
 [int]$RconPort=25578,
 [string]$InstancesRoot=(Join-Path $PSScriptRoot 'instances'),
 [string]$CacheModsDirectory,
 [string]$CacheLibrariesDirectory,
 [string]$CacheJavaDirectory,
 [switch]$AcceptEula
)
$ErrorActionPreference='Stop'
if($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9_-]{0,47}$'){throw 'Use a simple instance name with letters, numbers and hyphens.'}
if($Port -lt 1024 -or $Port -gt 65535 -or $RconPort -lt 1024 -or $RconPort -gt 65535 -or $Port -eq $RconPort){throw 'Choose two different unprivileged ports.'}
$taskRoot=[IO.Path]::GetFullPath($InstancesRoot)
$taskInstance=Join-Path $taskRoot $Name
if(Test-Path -LiteralPath $taskInstance){throw 'This instance already exists. Choose a new name to keep its world intact.'}
New-Item -ItemType Directory -Path $taskInstance -Force | Out-Null
Copy-Item -Path (Join-Path $PSScriptRoot 'payload/*') -Destination $taskInstance -Recurse -Force
foreach($taskFile in @('Start-Server.ps1','Stop-Server.ps1','Server-Command.ps1','mods.lock.json')){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $taskFile) -Destination $taskInstance}
$taskLock=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'mods.lock.json') -Raw | ConvertFrom-Json
foreach($taskMod in $taskLock.mods){
 if(!$taskMod.server){continue}
 $taskTarget=Join-Path $taskInstance ('mods/'+$taskMod.filename)
 $taskCached=if($CacheModsDirectory){Join-Path $CacheModsDirectory $taskMod.filename}else{$null}
 if($taskCached -and (Test-Path -LiteralPath $taskCached) -and (Get-FileHash -LiteralPath $taskCached).Hash.ToLowerInvariant() -eq $taskMod.sha256){Copy-Item -LiteralPath $taskCached -Destination $taskTarget}else{Invoke-WebRequest -Uri $taskMod.url -OutFile $taskTarget}
 if((Get-FileHash -LiteralPath $taskTarget).Hash.ToLowerInvariant() -ne $taskMod.sha256){throw ('Mod checksum mismatch: '+$taskMod.filename)}
}
if($CacheJavaDirectory){
 New-Item -ItemType Directory -Path (Join-Path $taskInstance 'runtime') -Force | Out-Null
 Copy-Item -LiteralPath $CacheJavaDirectory -Destination (Join-Path $taskInstance 'runtime/jdk-21') -Recurse -Force
 $taskJava=Join-Path $taskInstance 'runtime/jdk-21/bin/java.exe'
}else{
 $taskJava=(Get-Command java -ErrorAction Stop).Source
}
$taskSavedPreference=$ErrorActionPreference
try {
 # Windows PowerShell 5.1 treats Java's normal version output on stderr as an error record.
 $ErrorActionPreference='Continue'
 $taskJavaVersion=(& $taskJava -version 2>&1 | Out-String)
 $taskJavaExit=$LASTEXITCODE
} finally {$ErrorActionPreference=$taskSavedPreference}
if($taskJavaExit -ne 0){throw 'Java could not run. Verify the selected Java installation.'}
if($taskJavaVersion -notmatch 'version "21[\."]'){throw 'Java 21 is required. Install Java 21 and create a new instance name.'}
if($CacheLibrariesDirectory){Copy-Item -LiteralPath $CacheLibrariesDirectory -Destination (Join-Path $taskInstance 'libraries') -Recurse -Force}else{
 $taskInstaller=Join-Path $taskInstance $taskLock.installer.filename
 Invoke-WebRequest -Uri $taskLock.installer.url -OutFile $taskInstaller
 if((Get-FileHash -LiteralPath $taskInstaller).Hash.ToLowerInvariant() -ne $taskLock.installer.sha256){throw 'NeoForge installer checksum mismatch'}
 Push-Location $taskInstance
 try{& $taskJava -jar $taskInstaller --installServer;if($LASTEXITCODE -ne 0){throw 'NeoForge installation failed'}}finally{Pop-Location}
}
$taskArgs=Join-Path $taskInstance ('libraries/net/neoforged/neoforge/'+$taskLock.neoforge+'/win_args.txt')
if(!(Test-Path -LiteralPath $taskArgs)){throw 'NeoForge server arguments are missing.'}
$taskSecretBytes=New-Object byte[] 32
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($taskSecretBytes)
$taskSecret=[Convert]::ToBase64String($taskSecretBytes).TrimEnd('=').Replace('+','-').Replace('/','_')
$taskProperties=@"
server-port=$Port
server-ip=
level-name=world
level-seed=
level-type=minecraft:normal
gamemode=survival
force-gamemode=true
difficulty=hard
hardcore=false
online-mode=true
enforce-secure-profile=true
white-list=false
enforce-whitelist=false
max-players=10
spawn-protection=0
view-distance=8
simulation-distance=6
motd=Progression Survival - Friend Test
enable-command-block=false
enable-query=false
enable-rcon=true
rcon.port=$RconPort
rcon.password=$taskSecret
broadcast-rcon-to-ops=false
allow-flight=false
pvp=true
"@
[IO.File]::WriteAllText((Join-Path $taskInstance 'server.properties'),$taskProperties,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $taskInstance 'eula.txt'),('eula='+$AcceptEula.IsPresent.ToString().ToLowerInvariant()),[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $taskInstance 'user_jvm_args.txt'),"-Xms1G`n-Xmx4G`n",[Text.UTF8Encoding]::new($false))
foreach($taskFile in @('ops.json','whitelist.json','banned-players.json','banned-ips.json')){[IO.File]::WriteAllText((Join-Path $taskInstance $taskFile),'[]',[Text.UTF8Encoding]::new($false))}
@{name=$Name;packVersion=$taskLock.version;gamePort=$Port;rconPort=$RconPort;javaPath=$taskJava;freshWorld=$true} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskInstance 'instance.json') -Encoding utf8
Write-Output ('Fresh server instance created: '+$taskInstance)
if(!$AcceptEula){Write-Output 'Read https://aka.ms/MinecraftEULA and set eula=true if you agree before starting.'}
