# Progression Survival automatic updates

Import this ZIP once with Prism Add Instance > Import. Use Java 21 and 4 GB memory. The pre-launch command downloads the server-approved pack from jakemotta.com before Play. Review and accept Prism's custom-command warning only for this trusted download.

Keep your previous instance as a backup. With Minecraft closed, copy options.txt, servers.dat and your own saves/resourcepacks/shaderpacks/screenshots into this instance if needed. Do not copy old mods, pack-owned configs, launcher account files or updater state. Server progression stays on the server.

Updates require an Internet connection; a failed check blocks launch. This follows the server-approved channel, which can intentionally lag the latest published release. Minecraft/NeoForge upgrades require a new starter instance. Runtime installer versions are pinned; an updater-tool upgrade is delivered in a new starter.

Guide: https://jakemotta.com/downloads/progression-survival/packwiz/Install-and-Update.md
