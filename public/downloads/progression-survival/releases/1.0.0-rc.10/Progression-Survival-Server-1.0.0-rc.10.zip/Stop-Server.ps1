$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'Server-Command.ps1') -Command 'stop'
$taskLockPath=Join-Path $PSScriptRoot 'world/session.lock'
$taskDeadline=(Get-Date).AddSeconds(45)
do{
 Start-Sleep -Milliseconds 500
 try{
  $taskLock=[IO.File]::Open($taskLockPath,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
  $taskLock.Dispose()
  Write-Output 'Progression world saved and its session lock released.'
  exit 0
 }catch [IO.IOException]{}
}while((Get-Date) -lt $taskDeadline)
throw 'Shutdown has not released the world lock yet. Check the server log; do not force-close Java.'
