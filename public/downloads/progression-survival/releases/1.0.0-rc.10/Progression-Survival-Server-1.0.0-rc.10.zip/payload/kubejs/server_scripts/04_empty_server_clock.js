// Freeze the daylight cycle on an empty dedicated server; preserve deliberate manual freezes.
var EmptyClockRules=Java.loadClass('net.minecraft.world.level.GameRules');
var EmptyClockPath=Java.loadClass('net.minecraft.world.level.storage.LevelResource');
var EmptyClockLoaded=false,EmptyClockState={paused:false},EmptyClockTicks=0;
function emptyClockUpdate(server){
  var path=String(server.getWorldPath(EmptyClockPath.ROOT))+'/empty-server-clock.json';
  if(!EmptyClockLoaded){var raw=JsonIO.readString(path);if(raw&&raw!=='null')EmptyClockState=JSON.parse(raw);EmptyClockLoaded=true;}
  var occupied=server.getPlayerList().getPlayerCount()>0;
  var cycling=server.overworld().getGameRules().getBoolean(EmptyClockRules.RULE_DAYLIGHT);
  if(!occupied&&cycling){
    EmptyClockState.paused=true;JsonIO.write(path,EmptyClockState);
    server.runCommandSilent('gamerule doDaylightCycle false');
    console.info('[EmptyServerClock] Empty server: daylight cycle frozen.');
  }else if(occupied&&EmptyClockState.paused){
    server.runCommandSilent('gamerule doDaylightCycle true');
    EmptyClockState.paused=false;JsonIO.write(path,EmptyClockState);
    console.info('[EmptyServerClock] Player present: daylight cycle resumed.');
  }
}
ServerEvents.tick(function(e){if(++EmptyClockTicks%20===0)emptyClockUpdate(e.server);});
PlayerEvents.loggedIn(function(e){emptyClockUpdate(e.server);});