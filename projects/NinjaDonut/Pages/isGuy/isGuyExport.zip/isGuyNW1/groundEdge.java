import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class groundEdge here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class groundEdge extends Actor
{
    /**
     * Act - do whatever the groundEdge wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
