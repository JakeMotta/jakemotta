Pokemon: Green Foot Edition
Jacob Motta & Logan Lovell, May 2012, made in Greenfoot 2.1.2
https://jakemotta.com/project/greenfoot-pokemon

HOW TO RUN

You need Java 8 or newer (https://adoptium.net).

Unzip the whole folder first, then either:
  - double-click pokemon-green-foot-edition.jar, or
  - open a terminal in this folder and run:
      java -jar pokemon-green-foot-edition.jar

Keep the three jars together in one folder. The window is titled "V10",
the name of the 2012 project. It opens paused: press Run at the bottom.

Tested on Windows 10 with Java 25.

CONTROLS

  Space               start, on the title screen
  Left / Right, Enter choose your starter
  Arrow keys          walk (diagonals too); hold Shift to run
  Enter               close a sign, or pick from the battle menu
  S (hold)            your stats

Walking in the tall grass can start a wild battle. Battles only got as far
as a menu: Fight shows your starter's moves, Run takes you back to town.

WHAT'S IN HERE

  pokemon-green-foot-edition.jar  a small launcher, new in 2026: it starts
                                  the game and makes it open on the title
                                  screen (the 2012 export opens on the town
                                  and skips choosing a starter)
  V10.jar                         the game as exported in 2012, unchanged
  jl1.0.1.jar                     JLayer, which plays the battle music

CREDITS

A fan game. Pokemon and its characters, sprites and logo belong to
Nintendo, Game Freak and The Pokemon Company.
