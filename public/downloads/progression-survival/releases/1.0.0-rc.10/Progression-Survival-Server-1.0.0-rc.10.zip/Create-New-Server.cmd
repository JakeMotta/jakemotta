@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create-Server-Instance.ps1"
echo.
echo Read README.md for EULA acceptance and starting the new server.
pause
